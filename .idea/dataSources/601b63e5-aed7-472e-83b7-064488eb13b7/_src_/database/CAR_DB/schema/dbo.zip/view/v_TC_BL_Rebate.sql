      CREATE VIEW  [dbo].[v_TC_BL_Rebate] AS SELECT  * , CASE ticket_Type   when  1  then '优惠金额'   when  2   then '优惠时长'    end  as sticket_Type  , CASE IsUse         when  1  then '已用'       when  0   then '未用'        end  as sIsUse  FROM   TC_BL_Rebate
      GO
