      CREATE  PROCEDURE [dbo].[PDTC_DeleteInOut] ( @CarNo      varChar(9)             ) as  DELETE from TC_inoutls   where  CarNo=@CarNo  and  (Out_time IS NULL)  and I_GetData=1
      GO
