   CREATE VIEW dbo.V_TC_YHJMX AS Select A.C_Item , A.C_Type,A.C_No ,A.C_Name , B.BarCode,B.JZRQ,B.R_USE,B.H_Use from   Tc_Discount A , TC_coupon B WHERE  A.C_No= B.C_CODE
   GO
