    CREATE VIEW dbo.V_TC_M_T_Inside AS SELECT CASE SFLX   WHEN  1  THEN  '月卡车'     WHEN  2  THEN '临时车'    WHEN   3  THEN '免费车'  WHEN  4 THEN '储值车'  end AS sSFLX, CarNO ,SFLX ,IN_TIME ,CPLX , I_TDBH , I_PicNo  FROM TC_Inoutls where (Out_time IS NULL )  AND I_GetData=1 AND Inout_type=1 AND SFLX<>3
    GO
