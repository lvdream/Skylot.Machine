      CREATE procedure [dbo].P_backupdb(@ls_lj varchar(100)) as backup database CAR_DB to disk=@ls_lj with format,init,skip,nounload,stats=10
      GO
