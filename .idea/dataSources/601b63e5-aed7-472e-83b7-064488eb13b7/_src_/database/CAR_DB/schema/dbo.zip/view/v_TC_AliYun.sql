    CREATE VIEW  [dbo].[v_TC_AliYun] AS SELECT  * , CASE CarType   when  1  then '包月用户'   when  2   then '军警车'  when  3 then '政府用车' when  4 then '临时卡' when  5 then 'VIP用户'  end  as sCarType  , CASE In_Out    when  1  then '进场'       when  2   then '出场'    end  as sIn_Out  FROM   TC_AliYun
    GO
