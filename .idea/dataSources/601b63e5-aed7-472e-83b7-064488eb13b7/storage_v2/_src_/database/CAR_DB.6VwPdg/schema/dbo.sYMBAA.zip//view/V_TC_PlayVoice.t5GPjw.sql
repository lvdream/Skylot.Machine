    CREATE VIEW dbo.V_TC_PlayVoice AS SELECT  P_KEY ,CarNo ,C_Name,V_List , P_Count, CONVERT(varchar(100) , KSRQ, 111 ) AS KSRQ   ,CONVERT(varchar(100) ,JZRQ, 111 ) AS JZRQ ,h_Count ,Opertime ,Oper , V_TYPE, P_TYPE, CASE V_Type    when  1  then '个人'   when  2   then '全部'  end  as vType  , CASE P_Type    when  1  then '按次'   when  2   then '时段'  end  as pType  FROM   TC_PlayVoice
    GO
