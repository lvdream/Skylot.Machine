     CREATE PROCEDURE  [dbo].PDTC_GetDatetime ( @ServerDate   Datetime  Output       ) AS BEGIN Select @ServerDate =Getdate() END;
     GO
