    CREATE  VIEW dbo.V_TC_RunLog AS SELECT  * FROM dbo.All_RunLog  Where SystemType=3
    GO
