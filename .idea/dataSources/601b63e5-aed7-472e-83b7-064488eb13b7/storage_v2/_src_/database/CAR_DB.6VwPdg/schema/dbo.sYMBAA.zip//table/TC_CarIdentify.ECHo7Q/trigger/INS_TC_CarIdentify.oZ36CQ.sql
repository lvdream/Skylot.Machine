            CREATE TRIGGER [INS_TC_CarIdentify] ON [dbo].[TC_CarIdentify] AFTER INSERT AS DECLARE @CarNo     varchar(10) BEGIN TRANSACTION SET @CarNo       =(SELECT CarNo     FROM INSERTED) UPDATE   TC_Inoutls  SET SFLX=1  WHERE  CarNo=@CarNo  AND  SFLX=2  AND In_time is not null  AND  OUT_TIME IS NULL  COMMIT TRANSACTION
            GO
