CREATE PROCEDURE SP_OF_TR_after_insert_msi(IN sp_stage_id INT, IN sp_image_id INT, IN sp_image_createdate VARCHAR(20))
  BEGIN
DECLARE CONSTANT_MES_TYPE_YW varchar(1) DEFAULT '1';-- 消息类型：业务消息
DECLARE CONSTANT_STAGE_STRUCTURE_TYPE_DYS varchar(1) DEFAULT '1';-- 结构类型：单元式
DECLARE CONSTANT_MES_RECEIVETYPE_XMDD varchar(50) DEFAULT 'project.plan.dd';-- 人员类型：项目督导
DECLARE CONSTANT_MES_TITLE_BHTSC varchar(50) DEFAULT '编号图待上传';
DECLARE CONSTANT_MESSAGE_BHIMAGE_NEEDUPLOAD varchar(50) DEFAULT 'pms.bhimage.needupload';-- 编号图未编辑，请您尽快处理
DECLARE CONSTANT_MESSAGE_BHIMAGE_NEEDUPDATE varchar(50) DEFAULT 'pms.bhimage.needupdate';-- 设计师更新了立面图，请重新编辑编号图

DECLARE pro_id_int int(11);
DECLARE pro_name_str varchar(50);
DECLARE psps_createdate_str varchar(20);

DECLARE mes_title_str varchar(200);
DECLARE mes_content_str varchar(2000);
DECLARE mes_type_str varchar(1);
DECLARE mes_businesstype_str varchar(50);
DECLARE mes_businessid_str varchar(20);
DECLARE mes_receivetype_str varchar(50);
DECLARE mes_status_str varchar(1);
DECLARE mes_createdate_str varchar(20);
DECLARE mes_createuser_str varchar(20);
DECLARE mes_updatedate_str varchar(20);
DECLARE mes_updateuser_str varchar(20);

SELECT ps.pro_id INTO pro_id_int FROM mstb_project_stage ps WHERE ps.stage_id = sp_stage_id;
SET psps_createdate_str = 
	(SELECT psps.psps_createdate FROM oftb_project_stage_plate_summary psps WHERE psps.image_id = sp_image_id);

-- 如果立面图最新的记录时间大于或等于对应编号图的最新的记录时间，就视为设计师更新了立面图，通知督导重新上传编号图；
-- 否则，视为设计师上传了立面图，通知督导上传对应的编号图
IF (UNIX_TIMESTAMP(sp_image_createdate) >= UNIX_TIMESTAMP(psps_createdate_str)) THEN 
	SET mes_businesstype_str = CONSTANT_MESSAGE_BHIMAGE_NEEDUPDATE;
ELSE 
	SET mes_businesstype_str = CONSTANT_MESSAGE_BHIMAGE_NEEDUPLOAD;
END IF;

SET pro_name_str = (SELECT p.pro_name FROM mstb_project p WHERE p.pro_id = pro_id_int);

SET mes_title_str = CONSTANT_MES_TITLE_BHTSC;
SET mes_content_str = (SELECT dic.dic_name FROM cmtb_dictionary dic WHERE dic.dic_code = mes_businesstype_str);
SET mes_content_str = (SELECT REPLACE(mes_content_str,'[pro_name]',pro_name_str));
SET mes_type_str = CONSTANT_MES_TYPE_YW;
SET mes_businessid_str = pro_id_int;
SET mes_receivetype_str = CONSTANT_MES_RECEIVETYPE_XMDD;
SET mes_createdate_str = NOW();
SET mes_createuser_str = 'system';
SET mes_updatedate_str = '';
SET mes_updateuser_str = '';
SET mes_status_str = '1';

-- 消息记录创建之前，判断某个项目是否有已存在该信息
CALL SP_insert_tm(
	mes_title_str,
	mes_content_str,
	mes_type_str,
	mes_businesstype_str,
	mes_businessid_str,
	mes_receivetype_str,
	mes_status_str,
	mes_createdate_str,
	mes_createuser_str,
	mes_updatedate_str,
	mes_updateuser_str
);
END;
