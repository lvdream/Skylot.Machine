CREATE PROCEDURE SP_OF_TR_after_update_image_for_split(IN sp_image_id INT)
  BEGIN
DECLARE psps_code_str VARCHAR(200); -- 板块编号
DECLARE count_split_int INT; -- 定义设计单号对应分单主表里面分单个数
DECLARE stage_id_int INT ; -- 定义阶段id
DECLARE pro_id_int INT ; -- 定义工程项目id
DECLARE image_type_str VARCHAR(10); -- 定义立面图类型
DECLARE psa_id_int INT ; -- 定义设计单号
DECLARE count_mater_int INT; -- 定义设计单已通过审核材料个数
DECLARE dsm_status_str varchar(10); -- 定义分单显示状态0--不显示,1--显示
DECLARE done INT DEFAULT FALSE;
DECLARE psps_cur CURSOR  FOR SELECT psps_code 
          FROM oftb_project_stage_plate_summary WHERE image_id=sp_image_id;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

SELECT b.pro_id,b.stage_id,a.image_type INTO pro_id_int,stage_id_int,image_type_str
    FROM mstb_stage_image a 
    LEFT JOIN mstb_project_stage b 
    ON a.stage_id = b.stage_id WHERE image_id = sp_image_id;

OPEN psps_cur;
psps_loop:LOOP
FETCH psps_cur INTO psps_code_str;
  IF done THEN
      LEAVE psps_loop;
  END IF;
  -- 根据pro_id,psa_type,psa_code查询psa_id
  SET psa_id_int = (SELECT psa_id FROM mstb_project_stage_addtional WHERE 
      pro_id = pro_id_int AND psa_type = image_type_str AND psa_code = psps_code_str LIMIT 1);
  -- 计算分单主表中该设计单的在各阶段的总数
  SET count_split_int = (SELECT  COUNT(*) FROM mstb_design_split_main WHERE 
      stage_id = stage_id_int AND psa_id = psa_id_int);
  IF(count_split_int = '0') THEN -- 如果在分单主表中尚未存在该设计单的信息，那么执行下一步判断
    SET count_mater_int = (SELECT COUNT(*) FROM mstb_project_stage_addtional_material 
        WHERE psa_id = psa_id_int AND psam_status = '3');
    IF(count_mater_int = 0) THEN -- 如果设计单中不存在“完成订购设计审核”的材料，那么写入材料主表，状态为：'隐藏'
      INSERT INTO mstb_design_split_main(pro_id,stage_id,psa_id,psa_code,psa_type,dsm_status) 
      VALUES (pro_id_int,stage_id_int,psa_id_int,psps_code_str,image_type_str,'0');
    ELSE -- 如果设计单中存在“完成订购设计审核”的材料，那么写入材料主表，状态为：'待分单'
      INSERT INTO mstb_design_split_main(pro_id,stage_id,psa_id,psa_code,psa_type,dsm_status) 
      VALUES (pro_id_int,stage_id_int,psa_id_int,psps_code_str,image_type_str,'1');
    END IF;
  END IF; -- 如果在分单主表中已存在该设计单的信息，那么不做任何处理
END LOOP;
CLOSE psps_cur;
END;
