CREATE PROCEDURE SP_OF_TR_after_update_mpsa(IN sp_psa_id      INT, IN sp_pro_id INT, IN OLD_psa_status VARCHAR(2),
                                            IN NEW_psa_status VARCHAR(2))
  BEGIN
DECLARE CONSTANT_PSA_STATUS_INDESIGN varchar(2) DEFAULT '0'; -- 设计单状态：设计中
DECLARE CONSTANT_PSA_STATUS_DESIGNCOMPLETE varchar(2) DEFAULT '1'; -- 设计单状态：完成设计
DECLARE CONSTANT_PSA_STATUS_REVIEWING varchar(2) DEFAULT '2'; -- 设计单状态：审核中
DECLARE CONSTANT_PSA_STATUS_REVIEWCOMPLETE varchar(2) DEFAULT '3'; -- 设计单状态：完成审核
DECLARE CONSTANT_PSA_STATUS_ABANDON varchar(2) DEFAULT '-1'; -- 设计单状态：弃用

DECLARE CONSTANT_MESSAGE_DESIGN varchar(50) DEFAULT 'pms.design.create';-- 设计单未设计，请您尽快处理
DECLARE CONSTANT_REV_STATUS_QYBH varchar(1) DEFAULT '7';-- 审核单状态：弃用驳回(仅设计审核单有该状态)
DECLARE count int;

-- 设计单状态 设计中 》其它状态
IF (OLD_psa_status = CONSTANT_PSA_STATUS_INDESIGN 
	AND NEW_psa_status != CONSTANT_PSA_STATUS_INDESIGN) THEN 
	-- 查询该工程所有阶段的设计单处于“设计中”状态的数量
	SET count = (SELECT COUNT(*) FROM mstb_project_stage_addtional psa 
		WHERE psa.pro_id = sp_pro_id AND psa.psa_status = CONSTANT_PSA_STATUS_INDESIGN);
	-- 如果该工程所有阶段的设计单处于“设计中”状态的数量为0,更新消息表中相应状态
	IF (count = 0) THEN
		UPDATE tstb_message tm SET tm.mes_status = '0' 
			WHERE tm.mes_businesstype = CONSTANT_MESSAGE_DESIGN AND tm.mes_businessid = sp_pro_id;
	END IF;
END IF;

-- 设计单状态 其它状态 》设计中
IF (OLD_psa_status != CONSTANT_PSA_STATUS_INDESIGN 
	AND NEW_psa_status = CONSTANT_PSA_STATUS_INDESIGN) THEN 
	-- 查询该工程所有阶段的设计单处于“设计中”状态的数量
	SET count = (SELECT COUNT(*) FROM mstb_project_stage_addtional psa 
		WHERE psa.pro_id = sp_pro_id AND psa.psa_status = CONSTANT_PSA_STATUS_INDESIGN);
	-- 如果该工程所有阶段的该类型设计单处于“设计中”状态的数量为0,更新消息表中相应状态
	IF (count != 0) THEN
		UPDATE tstb_message tm SET tm.mes_status = '1' 
			WHERE tm.mes_businesstype = CONSTANT_MESSAGE_DESIGN AND tm.mes_businessid = sp_pro_id;
	END IF;
END IF;

-- -- 查看当前项目有效的弃用驳回的消息是否存在
-- IF EXISTS(SELECT 1 FROM tstb_message tm 
-- 				WHERE tm.mes_businesstype = 'pms.revorappr.reject.abandon' 
-- 				AND tm.mes_businessid = sp_pro_id AND tm.mes_status = '1') THEN
-- 	-- -- 设计单状态 完成设计 》审核中
-- 	-- 设计单状态变化
-- 	-- 设计中 》弃用、完成设计
-- 	-- 完成设计 》设计中、弃用、审核中
-- 	-- 审核中 》设计中、弃用、完成审核
-- 	-- 完成审核 》弃用
-- 	-- 弃用 》？
-- 	IF ((OLD_psa_status = CONSTANT_PSA_STATUS_DESIGNCOMPLETE 
-- 			AND NEW_psa_status = CONSTANT_PSA_STATUS_REVIEWING)
-- 		OR (OLD_psa_status != CONSTANT_PSA_STATUS_ABANDON 
-- 			AND NEW_psa_status = CONSTANT_PSA_STATUS_ABANDON)) THEN 
-- 		-- 检测所有校对/审核弃用驳回的审核单对应的设计单是否都在审核中、完成审核或者弃用状态
-- 		SET count = SELECT COUNT(*) FROM mstb_project_stage_addtional psa 
-- 			JOIN (
-- 				SELECT DISTINCT mmh.psa_id FROM mstb_material_history mmh 
-- 				JOIN (
-- 					SELECT mrh.hist_id FROM mstb_review mr 
-- 					JOIN mstb_review_history mrh 
-- 					ON mr.REV_ID = mrh.REV_ID 
-- 					WHERE REV_STATUS = CONSTANT_REV_STATUS_QYBH AND mr.PRO_ID = sp_pro_id) tmp1 
-- 				ON mmh.hist_id = tmp1.hist_id) tmp2
-- 			ON psa.psa_id = tmp2.psa_id 
-- 			WHERE (psa.psa_status = CONSTANT_PSA_STATUS_INDESIGN OR psa.psa_status = CONSTANT_PSA_STATUS_DESIGNCOMPLETE);
-- 		IF (count = 0) THEN 

-- 		END IF;
-- 	END IF;
-- END IF;
END;
