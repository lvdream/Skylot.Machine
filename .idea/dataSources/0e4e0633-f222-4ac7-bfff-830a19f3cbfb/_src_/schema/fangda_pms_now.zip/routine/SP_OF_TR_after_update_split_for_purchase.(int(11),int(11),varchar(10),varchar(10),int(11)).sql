CREATE PROCEDURE SP_OF_TR_after_update_split_for_purchase(IN sp_mdsm_id            INT, IN sp_dsm_id INT,
                                                          IN sp_mdsm_purchase_type VARCHAR(10),
                                                          IN sp_mdsm_optimize_type VARCHAR(10), IN sp_psam_id INT)
  BEGIN
DECLARE CONSTANT_PSA_TYPE_DYQDMJ varchar(2) DEFAULT '20';-- 单元清单埋件
DECLARE CONSTANT_PSA_TYPE_DYQDZST varchar(2) DEFAULT '21';-- 单元清单装饰条
DECLARE CONSTANT_PSA_TYPE_DYQDZJCL varchar(2) DEFAULT '22';-- 单元清单组件辅件
DECLARE CONSTANT_PSA_TYPE_KQDJMJ varchar(2) DEFAULT '25';-- 框架清单埋件
DECLARE CONSTANT_PSA_TYPE_KJQDGJ varchar(2) DEFAULT '26';-- 框架清单骨架
DECLARE CONSTANT_PSA_TYPE_KJQDZST varchar(2) DEFAULT '27';-- 框架清单装饰条
DECLARE CONSTANT_PSA_TYPE_KJQDZJCL varchar(2) DEFAULT '28';-- 框架清单组件辅件

DECLARE CONSTANT_IMAGE_STATUS_WCHZ varchar(2) DEFAULT '2';-- 完成绘制状态

DECLARE ipp_id_int INT; -- 分单方式id
DECLARE stage_id_int INT;-- 阶段id
DECLARE pro_id_int INT;-- pro_id
DECLARE mater_type_str VARCHAR(2);-- 材料类型
DECLARE psam_quantity_str VARCHAR(50);-- 设计单中材料的设计个数
DECLARE split_address_str  VARCHAR(50);-- 收货地点

DECLARE sum_plate_int INT; -- 定义已经完成编辑状态的立面图下的板块个数
DECLARE psa_code_str VARCHAR(50); -- 定义设计单号
DECLARE design_type_str varchar(4); -- 设计单类型
DECLARE psa_id_int INT; -- 定义设计单id
DECLARE psar_parent_code_str VARCHAR(100);
DECLARE psar_sub_code_str VARCHAR(100);
DECLARE psam_code_str VARCHAR(200);
DECLARE tps_design_num_int INT; -- 材料设计总量
DECLARE tps_purchased_num_int INT; -- 已提料总数
DECLARE tps_unpurchased_num_int INT; -- 待提料数量
DECLARE psa_type_str varchar(10);-- 设计单类型
DECLARE count_progress_int INT; -- 分单材料的流转过程数

DECLARE count_need_psa_int INT;-- 统计需优化设计单中的记录个数
  -- 采购方式“库存材料”不需要提料
IF (sp_mdsm_purchase_type != 'kc') THEN
  SET count_progress_int = (
    SELECT COUNT(*) FROM mstb_design_split_material_progress a WHERE mdsm_id = sp_mdsm_id) ;
  IF (count_progress_int = 0) THEN  -- 如果分单流转地址为：直发工地
    SET ipp_id_int = (
      SELECT a.ipp_id FROM iftb_purchase_plan a
      WHERE a.ipp_split_cg = sp_mdsm_purchase_type AND a.ipp_split_yh = sp_mdsm_optimize_type AND ISNULL(a.ipp_split_address) LIMIT 1
    ) ;
  ELSE
    SET split_address_str = (
      SELECT dsmp_address FROM mstb_design_split_material_progress WHERE mdsm_id = sp_mdsm_id ORDER BY dsmp_id ASC LIMIT 1
    ) ;
    SET ipp_id_int = (
      SELECT a.ipp_id FROM iftb_purchase_plan a
      WHERE a.ipp_split_cg = sp_mdsm_purchase_type AND a.ipp_split_yh = sp_mdsm_optimize_type AND a.ipp_split_address = split_address_str LIMIT 1
    ) ;
END IF ; 

IF (ISNULL(ipp_id_int)) THEN  -- 分单方式不存在
  INSERT INTO iftb_purchase_plan (
    ipp_split_cg,
    ipp_split_yh,
    ipp_split_address
  )
  VALUES
  (
    sp_mdsm_purchase_type,
    sp_mdsm_optimize_type,
    split_address_str
  ) ; 
  SET ipp_id_int = (SELECT LAST_INSERT_ID()) ;
END IF ; 

SELECT
  stage_id,
  pro_id,
  psa_code,
  psa_type,
  psa_id INTO stage_id_int,
  pro_id_int,
  psa_code_str,
  psa_type_str,
  psa_id_int
FROM
  mstb_design_split_main
WHERE
  dsm_id = sp_dsm_id LIMIT 1; 

SELECT
  prv_id,
  psam_quantity,
  psar_parent_code,
  psar_sub_code,
  psam_code INTO mater_type_str,
  psam_quantity_str,
  psar_parent_code_str,
  psar_sub_code_str,
  psam_code_str
FROM
  mstb_project_stage_addtional_material
WHERE
  psam_id = sp_psam_id LIMIT 1;

IF (psa_type_str = CONSTANT_PSA_TYPE_DYQDMJ OR psa_type_str = CONSTANT_PSA_TYPE_DYQDZST 
  OR psa_type_str = CONSTANT_PSA_TYPE_DYQDZJCL OR psa_type_str = CONSTANT_PSA_TYPE_KQDJMJ 
  OR psa_type_str = CONSTANT_PSA_TYPE_KJQDGJ OR psa_type_str = CONSTANT_PSA_TYPE_KJQDZST 
  OR psa_type_str = CONSTANT_PSA_TYPE_KJQDZJCL) THEN
  SET sum_plate_int = 1 ;
ELSE
  SET sum_plate_int = (
    SELECT
      SUM(psps_count)
    FROM
      oftb_project_stage_plate_summary s
    WHERE
      s.psps_code = psa_code_str
    AND s.image_id IN (
      SELECT
        image_id
      FROM
        mstb_stage_image h
      WHERE
        h.stage_id = stage_id_int
      AND h.image_type = psa_type_str
      AND h.image_status = CONSTANT_IMAGE_STATUS_WCHZ
    )
  ) ;
END IF ;

SET tps_design_num_int = sum_plate_int * (psam_quantity_str + 0) ; -- 计算设计总量

INSERT INTO tstb_purchaseplan_summary (
  ipp_id,
  stage_id,
  pro_id,
  psa_code,
  pv_id,
  psam_id,
  tps_design_num,
  tps_purchased_num,
  tps_unpurchased_num,
  psar_parent_code,
  psar_sub_code,
  psam_code,
  psam_quantity,
  psa_id,
  psa_type,
  ipp_split_yh
)
VALUES
  (
    ipp_id_int,
    stage_id_int,
    pro_id_int,
    psa_code_str,
    mater_type_str,
    sp_psam_id,
    tps_design_num_int,
    0,
    tps_design_num_int,
    psar_parent_code_str,
    psar_sub_code_str,
    psam_code_str,
    psam_quantity_str,
    psa_id_int,
    psa_type_str,
    sp_mdsm_optimize_type
  ) ;
END IF ;
END;
