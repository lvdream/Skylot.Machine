CREATE PROCEDURE SP_OF_TR_after_update_review(IN hist_id_int INT, IN pro_id_int INT, IN pst_id_int INT,
                                              IN rev_status  VARCHAR(10), IN rev_type VARCHAR(2))
  BEGIN
    -- 设计单表字段
    DECLARE psa_id_int INT; 
    DECLARE psa_name_str VARCHAR (200); 
    DECLARE psa_code_str VARCHAR (100); 
    DECLARE psa_backup_description_str VARCHAR (20); 
    DECLARE psa_size_str VARCHAR (50); 
    DECLARE psa_detail_size_str varchar(250); 
    DECLARE psa_component_area_str varchar(10); 
    DECLARE psa_action_area_str VARCHAR (20); 
    DECLARE psa_description_str VARCHAR (500); 
    DECLARE psa_status_int VARCHAR(2); 
    DECLARE psa_img_one_str VARCHAR (255); 
    DECLARE psa_img_two_str VARCHAR (255); 
    DECLARE psa_img_three_str VARCHAR (255); 
    DECLARE psa_option3_str VARCHAR (2000); 
    DECLARE psa_type_str VARCHAR (2); 

    -- 设计单组件关系表字段
    DECLARE psar_id_int INT; 
    DECLARE psar_name_str VARCHAR (1000); 
    DECLARE psar_parent_code_str VARCHAR (1000); 
    DECLARE psar_code_str VARCHAR (1000); 
    DECLARE psar_quantity_str VARCHAR (1000); 
    DECLARE psar_size_str VARCHAR (200); 
    DECLARE psar_description_str VARCHAR (1000); 
    DECLARE psar_status_str VARCHAR (1); 
    DECLARE psar_img_one_str VARCHAR (255); 
    DECLARE psar_img_two_str VARCHAR (255); 
    DECLARE psar_img_three_str VARCHAR (255); 

    -- 设计单材料表字段
    DECLARE psam_id_int INT; 
    DECLARE psam_name_str VARCHAR (200); 
    DECLARE psam_code_str VARCHAR (500); 
    DECLARE psam_process_size_str VARCHAR (200); 
    DECLARE psam_quantity_str VARCHAR (200); 
    DECLARE psam_description_str VARCHAR (1000); 
    DECLARE psam_option1_str VARCHAR (200); 
    DECLARE psam_option2_str VARCHAR (1000); 
    DECLARE psam_option5_str VARCHAR (1000); 
    DECLARE psam_status_str VARCHAR (10); 
    DECLARE prv_id_int VARCHAR (2); 

    DECLARE done INT DEFAULT FALSE; 
    DECLARE psa_cur CURSOR FOR
      SELECT
        `psa_id`,
        `psa_name`,
        `psa_code`,
        `psa_backup_description`,
        `psa_size`,
        `psa_detail_size`,
        `psa_component_area`,
        `psa_action_area`,
        `psa_description`,
        `psa_status`,
        `psa_img_one`,
        `psa_img_two`,
        `psa_img_three`,
        `psa_option3`
      FROM
        `mstb_plate_history`
      WHERE
        hist_id = hist_id_int; 

    DECLARE psar_cur CURSOR FOR
      SELECT
        `psar_id`,
        `psar_name`,
        `psar_parent_code`,
        `psar_code`,
        `psar_size`,
        `psar_quantity`,
        `psar_description`,
        `psar_status`,
        `psar_img_one`,
        `psar_img_two`,
        `psar_img_three`
      FROM
        `mstb_relationship_history`
      WHERE
        hist_id = hist_id_int; 

    DECLARE psam_cur CURSOR FOR
      SELECT
        `psam_id`,
        `psam_name`,
        `psam_code`,
        `psam_process_size`,
        `psam_quantity`,
        `psam_description`,
        `psam_option1`,
        `psam_option2`,
        `psam_option5`,
        `psam_status`,
        `prv_id`
      FROM
        `mstb_material_history`
      WHERE
        hist_id = hist_id_int; 

    DECLARE CONTINUE HANDLER FOR NOT FOUND
    SET done = TRUE; 

    -- 审核单批准通过
    IF (rev_status = '14') THEN
      OPEN psa_cur; 
      FETCH psa_cur INTO psa_id_int,
        psa_name_str,
        psa_code_str,
        psa_backup_description_str,
        psa_size_str,
        psa_detail_size_str,
        psa_component_area_str,
        psa_action_area_str,
        psa_description_str,
        psa_status_int,
        psa_img_one_str,
        psa_img_two_str,
        psa_img_three_str,
        psa_option3_str; 
      UPDATE mstb_project_stage_addtional SET
        psa_name = psa_name_str,
        psa_code = psa_code_str,
        psa_backup_description = psa_backup_description_str,
        psa_size = psa_size_str,
        psa_detail_size = psa_detail_size_str,
        psa_component_area = psa_component_area_str,
        psa_action_area = psa_action_area_str,
        psa_description = psa_description_str,
        psa_status = '3',
        psa_img_one = psa_img_one_str,
        psa_img_two = psa_img_two_str,
        psa_img_three = psa_img_three_str,
        psa_option3 = psa_option3_str
      WHERE
        psa_id = psa_id_int; 
      CLOSE psa_cur; 

      SET done = FALSE; 

      OPEN psar_cur; 
      pasr_loop : LOOP
        FETCH psar_cur INTO psar_id_int,
          psar_name_str,
          psar_parent_code_str,
          psar_code_str,
          psar_size_str,
          psar_quantity_str,
          psar_description_str,
          psar_status_str,
          psar_img_one_str,
          psar_img_two_str,
          psar_img_three_str; 
        IF done THEN
          LEAVE pasr_loop; 
        END IF; 
        UPDATE `mstb_project_stage_addtional_relationship` SET
          psar_name = psar_name_str,
          psar_parent_code = psar_parent_code_str,
          psar_code = psar_code_str,
          psar_size = psar_size_str,
          psar_quantity = psar_quantity_str,
          psar_description = psar_description_str,
          psar_status = psar_status_str,
          psar_img_one = psar_img_one_str,
          psar_img_two = psar_img_two_str,
          psar_img_three = psar_img_three_str
        WHERE
          psar_id = psar_id_int; 
      END LOOP; 
      CLOSE psar_cur; 

      SET done = FALSE; 

      OPEN psam_cur; 
      pasm_loop : LOOP
        FETCH psam_cur INTO psam_id_int,
          psam_name_str,
          psam_code_str,
          psam_process_size_str,
          psam_quantity_str,
          psam_description_str,
          psam_option1_str,
          psam_option2_str,
          psam_option5_str,
          psam_status_str,
          prv_id_int; 
        IF done THEN
          LEAVE pasm_loop; 
        END IF; 
        IF(rev_type = '2') THEN -- 加工审核单
          UPDATE `mstb_project_stage_addtional_material` SET psam_status = '6',
            psam_option2 = psam_option2_str,
            psam_option5 = psam_option5_str,
            psam_description = psam_description_str,
            psam_process_size = psam_process_size_str
          WHERE
            psam_id = psam_id_int AND psam_status != '-1'; 
        ELSEIF (rev_type = '1') THEN -- 订购审核单
          IF (psam_status_str = '0') THEN  -- 设计单材料状态：设计中
            -- UPDATE `mstb_project_stage_addtional_material` SET psam_status = '0' WHERE psam_id = psam_id_int; 
            DELETE FROM mstb_project_stage_addtional_material WHERE psam_id = psam_id_int AND psam_status = '2'; -- 2016/01/23 use this
          ELSE
            UPDATE `mstb_project_stage_addtional_material` SET psam_name = psam_name_str,
              psam_code = psam_code_str,
              psam_quantity = psam_quantity_str,
              psam_status = '3'
            WHERE psam_id = psam_id_int AND psam_status != '-1'; 

            SELECT psa_type INTO psa_type_str FROM mstb_project_stage_addtional_material psam
              LEFT JOIN mstb_project_stage_addtional psa
                ON psam.psa_id = psa.psa_id where psam_id = psam_id_int; 
            IF (prv_id_int != '1' AND (psa_type_str = '20' || psa_type_str = '21' || psa_type_str = '22' || psa_type_str = '25' || psa_type_str = '26' || psa_type_str = '27' || psa_type_str = '28')) THEN
              UPDATE mstb_project_stage_addtional_material SET psam_status = '6' WHERE psam_id = psam_id_int; 
            END IF; 

          END IF; 
        ELSE -- 设计审核单
          UPDATE
            `mstb_project_stage_addtional_material`
          SET
            psam_status = '3',
            psam_process_size = psam_process_size_str,
            psam_description = psam_description_str,
            psam_option1 = psam_option1_str,
            psam_option2 = psam_option2_str,
            psam_option5 = psam_option5_str
          WHERE
            psam_id = psam_id_int AND psam_status != '-1'; 
        END IF; 

      END LOOP; 
      CLOSE psam_cur; 
    -- 审核单弃用、弃用驳回、终止
    ELSEIF (rev_status = '6' || rev_status = '7' || rev_status = '8') THEN
      OPEN psa_cur; 
      FETCH psa_cur
      INTO psa_id_int,
        psa_name_str,
        psa_code_str,
        psa_backup_description_str,
        psa_size_str,
        psa_detail_size_str,
        psa_component_area_str,
        psa_action_area_str,
        psa_description_str,
        psa_status_int,
        psa_img_one_str,
        psa_img_two_str,
        psa_img_three_str,
        psa_option3_str; 
      UPDATE mstb_project_stage_addtional SET psa_status = '0' WHERE psa_id = psa_id_int; 
      CLOSE psa_cur; 

      SET done = FALSE; 

      OPEN psam_cur; 
      IF (rev_type = '1') THEN  -- 订购审核单
        pasm_loop : LOOP
          FETCH psam_cur INTO psam_id_int,
            psam_name_str,
            psam_code_str,
            psam_process_size_str,
            psam_quantity_str,
            psam_description_str,
            psam_option1_str,
            psam_option2_str,
            psam_option5_str,
            psam_status_str,
            prv_id_int; 
          IF done THEN
            LEAVE pasm_loop; 
          END IF; 
          UPDATE `mstb_project_stage_addtional_material` SET psam_status = '0' WHERE psam_id = psam_id_int AND psam_status != '-1'; 
        END LOOP; 
      ELSEIF(rev_type = '2') THEN -- 加工审核单
        pasm_loop : LOOP
          FETCH psam_cur INTO psam_id_int,
            psam_name_str,
            psam_code_str,
            psam_process_size_str,
            psam_quantity_str,
            psam_description_str,
            psam_option1_str,
            psam_option2_str,
            psam_option5_str,
            psam_status_str,
            prv_id_int; 
          IF done THEN
            LEAVE pasm_loop; 



          END IF; 
          UPDATE `mstb_project_stage_addtional_material` SET psam_status = '3' WHERE  psam_id = psam_id_int AND psam_status != '-1'; 
        END LOOP; 
      END IF; 
      CLOSE psam_cur; 
    END IF; 
  END;
