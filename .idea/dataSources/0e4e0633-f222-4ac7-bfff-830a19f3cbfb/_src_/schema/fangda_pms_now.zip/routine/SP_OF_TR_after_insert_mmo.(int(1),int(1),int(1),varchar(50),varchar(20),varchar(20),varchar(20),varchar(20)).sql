CREATE PROCEDURE SP_OF_TR_after_insert_mmo(IN sp_pro_id         INT(1), IN sp_prv_id INT(1), IN sp_mod_id INT(1),
                                           IN sp_mod_code       VARCHAR(50), IN sp_mod_createuser VARCHAR(20),
                                           IN sp_mod_createdate VARCHAR(20), IN sp_mod_updateuser VARCHAR(20),
                                           IN sp_mod_updatedate VARCHAR(20))
  BEGIN
DECLARE mos_noordered_num_int int(1);
DECLARE psam_code_str varchar(500);

DECLARE flag int DEFAULT 0;

DECLARE cur CURSOR FOR SELECT mos.psam_code,mos.mos_noordered_num FROM tstb_material_order_summary mos 
         WHERE mos.pro_id = sp_pro_id AND mos.prv_id = sp_prv_id;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;

OPEN cur;
LOOP_LABEL : LOOP
	FETCH cur INTO psam_code_str,mos_noordered_num_int;
	IF flag = 1 THEN
		LEAVE LOOP_LABEL;
	END IF;
	-- 订购单明细：只考虑待订购数量大于0的材料编号
	IF (mos_noordered_num_int > 0) THEN
		INSERT INTO mstb_material_order_detail (
			mod_id,
			pro_id,
			prv_id,
			mod_code,
			psam_code,
			modd_num,
			modd_status,
			modd_remark,
			modd_createuser,
			modd_createdate,
			modd_updateuser,
			modd_updatedate
		) VALUES (
			sp_mod_id,
			sp_pro_id,
			sp_prv_id,
			sp_mod_code,
			psam_code_str,
			mos_noordered_num_int,
			'1',
			'',
			sp_mod_createuser,
			sp_mod_createdate,
			sp_mod_updateuser,
			sp_mod_updatedate
		);
	END IF;
END LOOP;	
CLOSE cur;
END;
