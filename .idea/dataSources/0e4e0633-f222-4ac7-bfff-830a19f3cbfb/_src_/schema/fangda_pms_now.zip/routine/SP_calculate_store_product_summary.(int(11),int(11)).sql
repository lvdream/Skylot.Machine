CREATE PROCEDURE SP_calculate_store_product_summary(IN sp_pro_id INT, IN sp_psa_id INT)
  BEGIN
	DECLARE design_total_num int(11);
	DECLARE store_total_num int(11);
	DECLARE store_num int(11); -- 成品库存数量
	DECLARE update_result int DEFAULT 0; -- 最终要更新的成品数量
	DECLARE flag int DEFAULT 0;
	-- 数据1：查询该设计单的成品材料库存的数量和其本身的设计数量的倍数关系，取最小倍数
	-- 数据1需要满足的条件：该设计单的所有材料至少在成品材料库存中都存在

	-- 设计单对应的材料数
	SET design_total_num = (SELECT COUNT(*) FROM mstb_project_stage_addtional_material psam 
		WHERE psam.pro_id = sp_pro_id AND psam.psa_id = sp_psa_id);
	
	-- 设计单对应的材料库存数
	SET store_total_num = (SELECT COUNT(*) FROM mstb_store_product_material_summary spms 
		WHERE spms.pro_id = sp_pro_id AND spms.psa_id = sp_psa_id);

	IF(design_total_num = store_total_num) THEN 
		SET flag = 1;
	END IF;

	IF(flag = 1) THEN
		-- 数据2：查询该设计单的成品库存数量
		SET store_num = (SELECT (sps.sps_hadinstore_num - 
			(sps.sps_hadoutstore_num + sps.sps_bookoutstore_num)) 
			FROM mstb_store_product_summary sps 
			WHERE sps.pro_id = sp_pro_id AND sps.psa_id = sp_psa_id);
		BEGIN
			DECLARE psam_id_int int(11); -- 设计单材料ID
			DECLARE psam_quantity_str varchar(50);
			DECLARE psam_quantity_int int(11); -- 设计单材料设计数量

			DECLARE store_material_num int(11) DEFAULT 0; -- 成品材料库存数量
			DECLARE result int(11) DEFAULT 0;
			DECLARE inner_flag int DEFAULT 0;

			DECLARE cur CURSOR FOR SELECT psam.psam_id,psam.psam_quantity 
				FROM mstb_project_stage_addtional_material psam 
				WHERE psam.pro_id = sp_pro_id AND psam.psa_id = sp_psa_id;
			DECLARE CONTINUE HANDLER FOR NOT FOUND SET inner_flag = 1;
			OPEN cur;
			LOOP_LABEL : LOOP
				FETCH cur INTO psam_id_int,psam_quantity_str;
				IF inner_flag = 1 THEN
					LEAVE LOOP_LABEL;
				END IF;
				SET psam_quantity_int = CONVERT(psam_quantity_str,SIGNED);
				-- 计算材料的库存数量
				SET store_material_num = (SELECT (spms.spms_hadinstore_num - 
					(spms.spms_hadoutstore_num + spms.spms_bookoutstore_num)) 
					FROM mstb_store_product_material_summary spms 
					WHERE spms.pro_id = sp_pro_id AND spms.psa_id = sp_psa_id AND spms.psam_id = psam_id_int);
				-- 计算材料库存数量和设计数量的倍数与其对应的设计单成品的库存数量的差值，取最小整数值
				SET result = FLOOR(store_material_num / psam_quantity_int) - store_num;
				-- 比较数据1和数据2，如果(数据1 - 数据2)>=1，那么更新数据2；否则不做任何更新操作,要比较所有材料
				IF(result >= 1) THEN
					IF (result < update_result) THEN 
						SET update_result = result; -- 只要最小的倍数
					END IF;
					SET flag = 1;
			    ELSE 
			    	SET flag = 0;
			    	LEAVE LOOP_LABEL; -- 只要有一个材料不满足，那么就中断循环
				END IF;
			END LOOP;
			CLOSE cur;
		END;
	END IF;
	IF(flag = 1) THEN 
		UPDATE mstb_store_product_summary SET sps_hadinstore_num = sps_hadinstore_num + update_result 
		WHERE pro_id = sp_pro_id AND psa_id = sp_psa_id;
	END IF;
END;
