CREATE PROCEDURE SP_compare_materialandcooperate()
  BEGIN
DECLARE CONSTANT_CPL_REFER_MODULEID varchar(20) DEFAULT 'pms.cpl.design';-- 协作从属业务对象所属模块编号
DECLARE CONSTANT_CPL_REFER_ATTRIBUTEID varchar(50) DEFAULT 'pms.cpl.design.clqd';-- 协作从属业务对象子属性编号
DECLARE CONSTANT_TIMEOUT int(1) DEFAULT 30;
DECLARE cpl_id_int bigint(1);
DECLARE cpl_createdate bigint(1);
DECLARE currentdate bigint(1);
DECLARE flag int DEFAULT 0;
DECLARE cur CURSOR FOR 
	SELECT
		cpl.cpl_id,
		UNIX_TIMESTAMP(cpl.cpl_createdate) cpl_createdate,
		UNIX_TIMESTAMP(CURRENT_TIMESTAMP()) currentdate
	FROM
		tstb_cooperatelog cpl;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;
OPEN cur;
LOOP_LABEL : LOOP
	FETCH cur INTO cpl_id_int,cpl_createdate,currentdate;
	IF flag = 1 THEN
		LEAVE LOOP_LABEL;
	END IF;
	-- 如果未操作时间大于30分钟，那么就执行删除操作
	IF ((currentdate - cpl_createdate) > CONSTANT_TIMEOUT * 60) THEN 
		DELETE FROM tstb_cooperatelog WHERE cpl_id = cpl_id_int;
	END IF;
END LOOP;
CLOSE cur;
END;
