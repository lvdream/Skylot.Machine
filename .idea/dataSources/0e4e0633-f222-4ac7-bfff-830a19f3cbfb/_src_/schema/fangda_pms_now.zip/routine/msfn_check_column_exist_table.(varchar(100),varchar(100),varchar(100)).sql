CREATE FUNCTION msfn_check_column_exist_table(in_var_table_name VARCHAR(100), in_var_column VARCHAR(100),
                                              in_var_database   VARCHAR(100))
  RETURNS INT(1)
  BEGIN
  #create by saul @2016-01-14
  #check the column exist in the target TABLE
  #
	DECLARE
		int_countOfcolumn INT;

SELECT
	count(*) INTO int_countOfcolumn
FROM
	information_schema. COLUMNS
WHERE
	TABLE_SCHEMA = in_var_database
AND table_name = in_var_table_name
AND COLUMN_NAME = in_var_column;

RETURN int_countOfcolumn;
END;
