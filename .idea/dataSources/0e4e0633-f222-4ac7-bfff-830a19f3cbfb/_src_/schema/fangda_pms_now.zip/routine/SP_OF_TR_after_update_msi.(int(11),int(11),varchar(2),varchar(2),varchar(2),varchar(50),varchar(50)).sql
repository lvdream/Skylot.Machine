CREATE PROCEDURE SP_OF_TR_after_update_msi(IN sp_stage_id         INT, IN sp_image_id INT, IN sp_image_type VARCHAR(2),
                                           IN sp_OLD_image_status VARCHAR(2), IN sp_NEW_image_status VARCHAR(2),
                                           IN sp_image_updateuser VARCHAR(50), IN sp_image_updatedate VARCHAR(50))
  BEGIN
DECLARE CONSTANT_IMAGE_STATUS_NEEDDRAW varchar(2) DEFAULT '0';-- 立面图状态：已上传（待绘制）
DECLARE CONSTANT_IMAGE_STATUS_INDRAWING varchar(2) DEFAULT '1';-- 立面图状态：绘制中
DECLARE CONSTANT_IMAGE_STATUS_DRAWCOMPLETE varchar(2) DEFAULT '2';-- 立面图状态：绘制完成

DECLARE pro_id_int int(11); -- 定义项目序号
DECLARE count int;
DECLARE flag int DEFAULT 0;

-- 根据阶段ID查找工程项目ID
SET pro_id_int = (SELECT ps.pro_id FROM mstb_project_stage ps WHERE ps.stage_id = sp_stage_id);
-- 立面图状态变为“绘制完成”，批量生成设计单
IF(sp_NEW_image_status = CONSTANT_IMAGE_STATUS_DRAWCOMPLETE) THEN 
BEGIN
	DECLARE psa_option2_str varchar(2);-- 设计单激活状态
	DECLARE psps_code_str varchar(200);-- 设计单号
	DECLARE count_pro_int int(11) DEFAULT 0; -- 定义设计单对应的项目数量

	DECLARE flag int DEFAULT 0;

	-- 只考虑板块数量大于0的
	DECLARE cur CURSOR FOR SELECT psps.psps_code FROM oftb_project_stage_plate_summary psps 
		WHERE psps.psps_count > 0 AND psps.image_id = sp_image_id;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;
	OPEN cur;
	LOOP_LABEL : LOOP
		FETCH cur INTO psps_code_str;
		IF flag = 1 THEN 
			LEAVE LOOP_LABEL;
		END IF;
		-- 这里统计不包含清单设计单的类型
		SET count_pro_int = (SELECT COUNT(*) FROM mstb_project_stage_addtional psa 
			WHERE psa.pro_id = pro_id_int AND psa.psa_type = sp_image_type AND psa.psa_code = psps_code_str);
		-- 判断如果待插入的立面图编号在设计单列表中不存在，那么才进行插入设计单表的操作
		IF count_pro_int = 0 THEN
			-- 写入设计单表
			INSERT INTO mstb_project_stage_addtional(pro_id,pst_id,psa_code,psa_type,psa_createuser,psa_createdate) 
				VALUES (pro_id_int,sp_stage_id,psps_code_str,sp_image_type,sp_image_updateuser,sp_image_updatedate);
		-- 如果存在，且原先的设计单激活状态为“非激活”状态，那么就从“非激活”变成“激活”状态
		ELSE
			SET psa_option2_str := (
				SELECT psa.psa_option2 FROM mstb_project_stage_addtional psa 
					WHERE pro_id = pro_id_int AND psa_type = sp_image_type AND psa_code = psps_code_str LIMIT 1);
			IF(psa_option2_str = 0) THEN 
				UPDATE mstb_project_stage_addtional SET psa_option2 = '1' 
					WHERE pro_id = pro_id_int AND psa_type = sp_image_type AND psa_code = psps_code_str; 
			END IF;
		END IF;
	END LOOP;
	CLOSE cur;
END;
END IF;
END;
