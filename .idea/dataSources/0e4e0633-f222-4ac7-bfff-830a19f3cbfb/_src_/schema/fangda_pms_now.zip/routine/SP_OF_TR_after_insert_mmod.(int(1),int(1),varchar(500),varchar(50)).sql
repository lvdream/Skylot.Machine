CREATE PROCEDURE SP_OF_TR_after_insert_mmod(IN sp_pro_id   INT(1), IN sp_prv_id INT(1), IN sp_psam_code VARCHAR(500),
                                            IN sp_mod_code VARCHAR(50))
  BEGIN
DECLARE mos_ordered_num_int int(1);
DECLARE mos_noordered_num_int int(1);
DECLARE mos_orders_str varchar(2000);

SELECT mos.mos_ordered_num,mos.mos_noordered_num,mos.mos_orders 
	INTO mos_ordered_num_int,mos_noordered_num_int,mos_orders_str 
	FROM tstb_material_order_summary mos 
	WHERE mos.pro_id = sp_pro_id AND mos.prv_id = sp_prv_id AND mos.psam_code = sp_psam_code;

-- 拼接所有的订购单号
IF (ISNULL(mos_orders_str) || mos_orders_str = '') THEN 
	SET mos_orders_str = sp_mod_code;
ELSE 
	SET mos_orders_str = CONCAT(mos_orders_str,';',sp_mod_code);
END IF;

-- 已订购数量 = 原有订购数量 + 待订购数量
SET mos_ordered_num_int = mos_ordered_num_int + mos_noordered_num_int;

-- 更新订购单汇总表
UPDATE tstb_material_order_summary 
	SET mos_ordered_num = mos_ordered_num_int,
		mos_noordered_num = 0,
		mos_status = '1',
		mos_updatedate = NOW(),
		mos_orders = mos_orders_str
	WHERE pro_id = sp_pro_id AND prv_id = sp_prv_id AND psam_code = sp_psam_code;
END;
