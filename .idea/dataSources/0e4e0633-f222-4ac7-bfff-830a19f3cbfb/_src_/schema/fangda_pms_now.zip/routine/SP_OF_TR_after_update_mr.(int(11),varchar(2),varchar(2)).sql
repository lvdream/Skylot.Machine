CREATE PROCEDURE SP_OF_TR_after_update_mr(IN old_pro_id INT, IN old_rev_status VARCHAR(2), IN new_rev_status VARCHAR(2))
  BEGIN
DECLARE CONSTANT_REV_STATUS_DJD varchar(1) DEFAULT '1';-- 审核单状态：待校对
DECLARE CONSTANT_REV_STATUS_DSH varchar(1) DEFAULT '2';-- 审核单状态：待审核
DECLARE CONSTANT_REV_STATUS_JDBH varchar(1) DEFAULT '3';-- 审核单状态：校对驳回
DECLARE CONSTANT_REV_STATUS_SHTG varchar(1) DEFAULT '4';-- 审核单状态：审核通过
DECLARE CONSTANT_REV_STATUS_SHBH varchar(1) DEFAULT '5';-- 审核单状态：审核驳回
DECLARE CONSTANT_REV_STATUS_QY varchar(1) DEFAULT '6';-- 审核单状态：弃用
DECLARE CONSTANT_REV_STATUS_QYBH varchar(1) DEFAULT '7';-- 审核单状态：弃用驳回(仅设计审核单有该状态)

DECLARE CONSTANT_MES_TYPE_YW varchar(1) DEFAULT '1';-- 消息类型：业务消息

DECLARE CONSTANT_MES_RECEIVETYPE_SJS varchar(50) DEFAULT 'project.plan.sjs';-- 人员类型：设计师
DECLARE CONSTANT_MES_RECEIVETYPE_JDRY varchar(50) DEFAULT 'project.plan.xdry';-- 人员类型：校对人员
DECLARE CONSTANT_MES_RECEIVETYPE_SHRY varchar(50) DEFAULT 'project.plan.shry';-- 人员类型：审核人员

DECLARE CONSTANT_MES_TITLE_JDDCJ varchar(50) DEFAULT '校对单创建';
DECLARE CONSTANT_MES_TITLE_SHDCJ varchar(50) DEFAULT '审核单创建';
DECLARE CONSTANT_MES_TITLE_JDDSHDZJBH varchar(50) DEFAULT '校对/审核单直接驳回';
DECLARE CONSTANT_MES_TITLE_JDDSHDQYBH varchar(50) DEFAULT '校对/审核单弃用驳回';

DECLARE CONSTANT_MESSAGE_REVIEW varchar(50) DEFAULT 'pms.review.create';-- 校对单未校对，请您尽快处理
DECLARE CONSTANT_MESSAGE_APPROVAL varchar(50) DEFAULT 'pms.approval.create';-- 审核单未审核，请您尽快处理
DECLARE CONSTANT_MESSAGE_JDDSHDZJBH varchar(50) DEFAULT 'pms.revorappr.reject.direct';-- 校对/审核单直接驳回
DECLARE CONSTANT_MESSAGE_JDDSHDQYBH varchar(50) DEFAULT 'pms.revorappr.reject.abandon';-- 校对/审核单弃用驳回

DECLARE pro_name_str varchar(50);
DECLARE count int;

DECLARE mes_title_str varchar(200);
DECLARE mes_content_str varchar(2000);
DECLARE mes_type_str varchar(1);
DECLARE mes_businesstype_str varchar(50);
DECLARE mes_businessid_str varchar(20);
DECLARE mes_receivetype_str varchar(50);
DECLARE mes_status_str varchar(1);
DECLARE mes_createdate_str varchar(20);
DECLARE mes_createuser_str varchar(20);
DECLARE mes_updatedate_str varchar(20);
DECLARE mes_updateuser_str varchar(20);

-- 当校对单状态[校对驳回 3] 》[待校对 1]，审核单状态[审核驳回 5] 》[待校对 1]
-- 生成校对单
IF ((old_rev_status = CONSTANT_REV_STATUS_JDBH AND new_rev_status = CONSTANT_REV_STATUS_DJD)
	OR (old_rev_status = CONSTANT_REV_STATUS_SHBH AND new_rev_status = CONSTANT_REV_STATUS_DJD)) THEN 
	SET mes_title_str = CONSTANT_MES_TITLE_JDDCJ;
	SET mes_receivetype_str = CONSTANT_MES_RECEIVETYPE_JDRY;
	SET mes_businesstype_str = CONSTANT_MESSAGE_REVIEW;
-- 当校对单状态[待校对 1] 》[待审核 2]
-- 生成审核单
ELSEIF (old_rev_status = CONSTANT_REV_STATUS_DJD AND new_rev_status = CONSTANT_REV_STATUS_DSH) THEN
	SET mes_title_str = CONSTANT_MES_TITLE_SHDCJ;
	SET mes_receivetype_str = CONSTANT_MES_RECEIVETYPE_SHRY;
	SET mes_businesstype_str = CONSTANT_MESSAGE_APPROVAL;
-- 当校对单状态[待校对 1] 》[校对驳回 3] OR [待审核 2] 》[审核驳回 5]
-- 校对单/审核单直接驳回
ELSEIF ((old_rev_status = CONSTANT_REV_STATUS_DJD AND new_rev_status = CONSTANT_REV_STATUS_JDBH) 
	OR (old_rev_status = CONSTANT_REV_STATUS_DSH AND new_rev_status = CONSTANT_REV_STATUS_SHBH)) THEN
	SET mes_title_str = CONSTANT_MES_TITLE_JDDSHDZJBH;
	SET mes_receivetype_str = CONSTANT_MES_RECEIVETYPE_SJS;
	SET mes_businesstype_str = CONSTANT_MESSAGE_JDDSHDZJBH;
-- 当校对单状态[待校对 1] 》[弃用驳回 7] OR [待审核 2] 》[弃用驳回 7]
-- 校对单/审核单弃用驳回
ELSEIF ((old_rev_status = CONSTANT_REV_STATUS_DJD AND new_rev_status = CONSTANT_REV_STATUS_QYBH) 
	OR (old_rev_status = CONSTANT_REV_STATUS_DSH AND new_rev_status = CONSTANT_REV_STATUS_QYBH)) THEN
	SET mes_title_str = CONSTANT_MES_TITLE_JDDSHDQYBH;
	SET mes_receivetype_str = CONSTANT_MES_RECEIVETYPE_SJS;
	SET mes_businesstype_str = CONSTANT_MESSAGE_JDDSHDQYBH;
END IF;
-- 校对单/审核单弃用？？？,这个操作由设计师完成
IF (mes_businesstype_str != '' AND !ISNULL(mes_businesstype_str)) THEN
	SET pro_name_str = (SELECT p.pro_name FROM mstb_project p WHERE p.pro_id = old_pro_id);
	SET mes_content_str = 
		(SELECT dic.dic_name FROM cmtb_dictionary dic WHERE dic.dic_code = mes_businesstype_str);
	SET mes_content_str = (SELECT REPLACE(mes_content_str,'[pro_name]',pro_name_str));
	SET mes_type_str = CONSTANT_MES_TYPE_YW;
	SET mes_businessid_str = old_pro_id;
	SET mes_createdate_str = NOW();
	SET mes_createuser_str = 'system';
	SET mes_updatedate_str = '';
	SET mes_updateuser_str = '';
	SET mes_status_str = '1';

	-- 消息记录创建之前，判断某个项目是否有已存在该信息
	CALL SP_insert_tm(
		mes_title_str,
		mes_content_str,
		mes_type_str,
		mes_businesstype_str,
		mes_businessid_str,
		mes_receivetype_str,
		mes_status_str,
		mes_createdate_str,
		mes_createuser_str,
		mes_updatedate_str,
		mes_updateuser_str
	);
END IF;

-- 消息隐藏
-- 1）校对单待校对消息隐藏；当前项目中没有待校对的材料或者设计审核单
-- 2）审核单待审核消息隐藏；当前项目中没有待审核的材料或者设计审核单
-- 3）审核单待校对/审核驳回消息隐藏；当前项目中没有校对/审核驳回的材料或者设计审核单

-- 校对单待校对消息隐藏；审核单从[待校对 2] 》[其他状态]
IF (old_rev_status = CONSTANT_REV_STATUS_DJD AND new_rev_status != CONSTANT_REV_STATUS_DJD) THEN
	-- 查询项目中待校对的审核单数量
	SET count = (SELECT COUNT(*) FROM mstb_review mr 
		WHERE mr.pro_id = old_pro_id AND mr.rev_status = CONSTANT_REV_STATUS_DJD);
	SET mes_businesstype_str = CONSTANT_MESSAGE_REVIEW;
	IF (count = 0) THEN 
		UPDATE tstb_message tm SET tm.mes_status = '0' 
			WHERE tm.mes_businesstype = mes_businesstype_str AND tm.mes_businessid = old_pro_id;
	END IF;
END IF;

-- 审核单待审核消息隐藏；审核单从[待校对 2] 》[其他状态]
IF (old_rev_status = CONSTANT_REV_STATUS_DSH AND new_rev_status != CONSTANT_REV_STATUS_DSH) THEN
	SET count = (SELECT COUNT(*) FROM mstb_review mr 
		WHERE mr.pro_id = old_pro_id AND mr.rev_status = CONSTANT_REV_STATUS_DSH);
	SET mes_businesstype_str = CONSTANT_MESSAGE_APPROVAL;
	IF (count = 0) THEN 
		UPDATE tstb_message tm SET tm.mes_status = '0' 
			WHERE tm.mes_businesstype = mes_businesstype_str AND tm.mes_businessid = old_pro_id;
	END IF;
END IF;

-- 校对单、审核单直接驳回消息隐藏
-- 条件：校对单、审核单直接驳回消息隐藏；审核单从[校对驳回 3 | 审核驳回 5] 》[其他状态]
IF ((old_rev_status = CONSTANT_REV_STATUS_JDBH AND new_rev_status != CONSTANT_REV_STATUS_JDBH) OR 
	(old_rev_status = CONSTANT_REV_STATUS_SHBH AND new_rev_status != CONSTANT_REV_STATUS_SHBH)) THEN
	SET mes_businesstype_str = CONSTANT_MESSAGE_JDDSHDZJBH;
	SET count = (SELECT COUNT(*) FROM mstb_review mr 
		WHERE mr.pro_id = old_pro_id 
		AND (mr.rev_status = CONSTANT_REV_STATUS_JDBH OR mr.rev_status = CONSTANT_REV_STATUS_SHBH));
	IF (count = 0) THEN 
		UPDATE tstb_message tm SET tm.mes_status = '0' 
			WHERE tm.mes_businesstype = mes_businesstype_str AND tm.mes_businessid = old_pro_id;
	END IF;
END IF;
END;
