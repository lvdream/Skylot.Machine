CREATE PROCEDURE SP_OF_TR_after_update_summary_for_purchase(IN sp_image_id  INT, IN sp_psps_code VARCHAR(150),
                                                            IN stage_id_int INT, IN image_status_str VARCHAR(150),
                                                            IN psa_type_str VARCHAR(150))
  BEGIN
DECLARE sum_plate_int INT;-- 定义实时板块的个数
DECLARE psam_quantity_int INT;-- 定义材料设计个数
DECLARE tps_id_int INT; -- 提料总表id
DECLARE tps_design_num_int INT;-- 材料设计总量
DECLARE tps_purchased_num_int INT;-- 已提料总数
DECLARE tps_unpurchased_num_int INT;-- 待提料数量
DECLARE psam_id_int INT; -- 材料id
DECLARE error_count_int INT;-- 已采购数量
DECLARE done INT DEFAULT FALSE;
DECLARE psam_cur CURSOR FOR SELECT
                tps_id,
                psam_quantity,
                tps_purchased_num,
                psam_id
        FROM
                tstb_purchaseplan_summary 
				
        WHERE
                psa_code = sp_psps_code
        AND stage_id = stage_id_int AND psa_type=psa_type_str;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;


-- 计算总个数
SET sum_plate_int = (
        SELECT
                SUM(psps_count)
        FROM
                oftb_project_stage_plate_summary s
        WHERE
                s.psps_code = sp_psps_code
        AND s.image_id IN (
                SELECT
                        image_id
                FROM
                        mstb_stage_image h
                WHERE h.stage_id = stage_id_int AND h.image_type=psa_type_str
        )
);

OPEN psam_cur;
pasm_loop :LOOP
  FETCH psam_cur INTO tps_id_int,psam_quantity_int,tps_purchased_num_int,psam_id_int;
IF done THEN
  LEAVE pasm_loop;
END IF;

SET tps_design_num_int = sum_plate_int * psam_quantity_int; -- 计算设计总量
SET tps_unpurchased_num_int = tps_design_num_int - tps_purchased_num_int;
IF (image_status_str = '2') THEN -- 如果立面图是已经完成编辑状态，任何修改都是属于设计变更
            -- 已经提料的数据不会去改变,只记录下误差数即可
        IF(tps_unpurchased_num_int>0)THEN 
        UPDATE tstb_purchaseplan_summary SET tps_design_num = tps_design_num_int,
                   tps_unpurchased_num = tps_unpurchased_num_int,tps_err_num=0 WHERE tps_id = tps_id_int;
  ELSE
    UPDATE tstb_purchaseplan_summary SET tps_design_num = tps_design_num_int,
                   tps_unpurchased_num = 0,tps_err_num=tps_purchased_num_int-tps_design_num_int
                                                                        WHERE tps_id = tps_id_int;
  END IF;
ELSE -- 立面图状态没有完成编辑状态，则只需要变更设计总数即可
 UPDATE tstb_purchaseplan_summary SET tps_design_num = tps_design_num_int
                                                                        WHERE tps_id = tps_id_int;
END IF;
END LOOP;
CLOSE psam_cur;


END;
