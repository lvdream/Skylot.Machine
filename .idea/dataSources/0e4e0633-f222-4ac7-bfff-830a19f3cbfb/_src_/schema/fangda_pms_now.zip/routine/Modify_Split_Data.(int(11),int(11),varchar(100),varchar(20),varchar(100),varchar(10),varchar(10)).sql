CREATE PROCEDURE Modify_Split_Data(IN sp_pro_id          INT, IN sp_stage_id INT, IN sp_psa_code VARCHAR(100),
                                   IN sp_mdsm_createuser VARCHAR(20), IN sp_dsmp_address VARCHAR(100),
                                   IN sp_dsmp_type       VARCHAR(10), IN sp_dsmp_material_type VARCHAR(10))
  BEGIN
 -- 临时使用的存储过程
  DECLARE mdsm_id_int INT ; -- 只考虑板块数量大于0的
  DECLARE flag INT DEFAULT FALSE;
  DECLARE cur CURSOR FOR SELECT mdsm_id FROM mstb_design_split_material mdsm
      JOIN mstb_design_split_main dsm ON mdsm.dsm_id = dsm.dsm_id
        WHERE dsm.pro_id = sp_pro_id AND dsm.stage_id = sp_stage_id AND dsm.psa_code = sp_psa_code AND mdsm_createuser = sp_mdsm_createuser ; 
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1 ; 
    OPEN cur ; 
    LOOP_LABEL :
    LOOP
      FETCH cur INTO mdsm_id_int ;
    IF flag = 1 THEN
      LEAVE LOOP_LABEL ;
    END IF ; 

    INSERT INTO mstb_design_split_material_progress (
      mdsm_id,
      dsmp_address,
      dsmp_type,
      dsmp_material_type
    ) VALUES (
      mdsm_id_int,
      sp_dsmp_address,
      sp_dsmp_type,
      sp_dsmp_material_type
    ) ;
    END LOOP ; 
  CLOSE cur ;
END;
