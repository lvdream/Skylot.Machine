CREATE PROCEDURE SP_OF_TR_after_insert_msi_hide(IN sp_stage_id INT)
  BEGIN
DECLARE pro_id_int int(11);
DECLARE stage_id_int int(11);
DECLARE hide_flag int DEFAULT 1; -- 默认隐藏
DECLARE mes_businesstype_str varchar(50);
DECLARE CONSTANT_STAGE_STRUCTURE_TYPE_DYS varchar(1) DEFAULT '1';-- 结构类型：单元式
DECLARE CONSTANT_MESSAGE_LMIMAGE_NEEDUPLOAD varchar(50) DEFAULT 'pms.lmimage.needupload';-- 立面图未上传，请您尽快处理

DECLARE count int;

DECLARE flag int DEFAULT 0;

-- 根据阶段ID查找工程项目ID
SET pro_id_int := (SELECT ps.pro_id FROM mstb_project_stage ps WHERE ps.stage_id = sp_stage_id);
	-- 查找出工程项目中所有的阶段
	BEGIN
	DECLARE cur CURSOR FOR SELECT ps.stage_id FROM mstb_project_stage ps WHERE ps.pro_id = pro_id_int;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;
	OPEN cur;
	LOOP_LABEL : LOOP
		FETCH cur INTO stage_id_int;
		IF flag = 1 THEN 
			LEAVE LOOP_LABEL;
		END IF;
		-- 是否每个阶段都至少上传一张立面图
		SET count = (SELECT COUNT(*) FROM mstb_stage_image msi WHERE msi.stage_id = stage_id_int);
		IF (count = 0) THEN 
			SET hide_flag = 0;
			LEAVE LOOP_LABEL;
		END IF; 
	END LOOP;
	CLOSE cur;
	IF (hide_flag = 1) THEN 
		SET mes_businesstype_str = CONSTANT_MESSAGE_LMIMAGE_NEEDUPLOAD;
		UPDATE tstb_message tm SET tm.mes_status = '0' 
			WHERE tm.mes_businesstype = mes_businesstype_str AND tm.mes_businessid = pro_id_int;
	END IF;
	END;
END;
