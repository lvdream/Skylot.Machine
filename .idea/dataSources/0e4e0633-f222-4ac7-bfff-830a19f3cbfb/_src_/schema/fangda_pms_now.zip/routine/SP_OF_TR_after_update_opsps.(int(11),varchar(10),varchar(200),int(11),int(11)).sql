CREATE PROCEDURE SP_OF_TR_after_update_opsps(IN sp_pro_id         INT, IN sp_psps_type VARCHAR(10),
                                             IN sp_psps_code      VARCHAR(200), IN sp_OLD_psps_count INT,
                                             IN sp_NEW_psps_count INT)
  BEGIN
DECLARE abandon_flag int DEFAULT 0; -- 弃用标志，默认为不弃用
DECLARE count int; -- 计数

-- 板块数量变为0之后
IF(sp_OLD_psps_count != 0 AND sp_NEW_psps_count = 0) THEN 
	BEGIN
	-- 查找项目中所有阶段某类型板块在编号图中出现的记录总数
	SET count := (SELECT SUM(psps.psps_count) FROM mstb_stage_image msi JOIN oftb_project_stage_plate_summary psps 
		ON msi.image_id = psps.image_id AND msi.image_type = sp_psps_type 
		AND psps.pro_id = sp_pro_id AND psps.psps_code = sp_psps_code
	);

	-- 如果某类型板块在在编号图中出现的记录总数总和为0，那么便需要将其弃用掉。
	IF(count = 0) THEN 
		SET abandon_flag = 1;
	ELSE 
		SET abandon_flag = 0;
	END IF;

	IF(abandon_flag = 1) THEN
		UPDATE mstb_project_stage_addtional SET psa_option2 = '0' WHERE pro_id = sp_pro_id AND psa_type = sp_psps_type AND psa_code = sp_psps_code; 
	END IF;
	END;
END IF;
END;
