CREATE PROCEDURE SP_clear_cooperatelog()
  BEGIN
	TRUNCATE tstb_cooperatelog;
END;
