CREATE FUNCTION FN_SPLIT_STR(f_string VARCHAR(1000), f_delimiter VARCHAR(5), f_order INT)
  RETURNS VARCHAR(255)
  BEGIN
    declare result varchar(1000) character SET utf8 DEFAULT '' ; 
    SET result = reverse(substring_index(reverse(substring_index(f_string,f_delimiter,f_order)),f_delimiter,1)); 
    RETURN result; 
  END;
