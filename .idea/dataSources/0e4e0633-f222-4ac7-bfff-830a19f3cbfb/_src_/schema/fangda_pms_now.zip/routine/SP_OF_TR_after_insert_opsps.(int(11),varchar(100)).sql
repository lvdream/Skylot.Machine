CREATE PROCEDURE SP_OF_TR_after_insert_opsps(IN sp_image_id INT, IN sp_psps_code VARCHAR(100))
  BEGIN

DECLARE CONSTANT_STAGE_STRUCTURE_TYPE_DYS varchar(2) DEFAULT '1'; -- 单元式
DECLARE CONSTANT_STAGE_STRUCTURE_TYPE_KJS varchar(2) DEFAULT '2'; -- 框架式
DECLARE CONSTANT_PSA_TYPE_DYZJ varchar(1) DEFAULT '2';-- 单元组件
DECLARE CONSTANT_PSA_TYPE_KJMB varchar(1) DEFAULT '6';-- 框架面板
DECLARE pst_id_int int; -- 定义阶段序号
DECLARE pro_id_int int; -- 定义项目序号
DECLARE stage_structure_type_str varchar(2); -- 阶段结构图类型
DECLARE count_pro_int int default 0; -- 定义设计单对应的项目数量
DECLARE psa_type_tmp varchar(1); -- 设计单类型
DECLARE count_split_int int;-- 分单个数
DECLARE psa_id_int int;-- 定义设计单号
DECLARE psa_type_str varchar(4) ;-- 定义设计单类型

-- 根据立面图ID查询阶段ID
SET pst_id_int = (SELECT stage_id FROM mstb_stage_image WHERE image_id = sp_image_id LIMIT 1); -- 根据阶段ID查找工程项目ID
SELECT pro_id,stage_structure_type INTO pro_id_int,stage_structure_type_str FROM mstb_project_stage WHERE stage_id = pst_id_int ; -- 查询某个工程项目中某种类型板块是否在设计单中已经存在，实际使用中，单元式和框架式不会出现相同的板块名称
IF (stage_structure_type_str = CONSTANT_STAGE_STRUCTURE_TYPE_DYS) THEN
	SET psa_type_tmp = CONSTANT_PSA_TYPE_DYZJ;
ELSEIF (stage_structure_type_str = CONSTANT_STAGE_STRUCTURE_TYPE_KJS) THEN
	SET psa_type_tmp = CONSTANT_PSA_TYPE_KJMB ;
END IF ;
SET count_pro_int = (
	SELECT COUNT(*) FROM mstb_project_stage_addtional
	WHERE pro_id = pro_id_int AND psa_code = sp_psps_code AND psa_type = psa_type_tmp
) ;
IF count_pro_int = 0 THEN
	-- 判断如果待插入的立面图编号在设计单列表中不存在，那么才进行插入设计单表的操作
	-- 写入设计单表
 INSERT INTO mstb_project_stage_addtional (
	pro_id,
	pst_id,
	psa_code,
	psa_type
)
 VALUES(
	pro_id_int,
	pst_id_int,
	sp_psps_code,
	psa_type_tmp
) ;
END IF ;
SET count_split_int = (
	SELECT count(*) FROM mstb_design_split_main WHERE psa_code = sp_psps_code AND stage_id = pst_id_int
) ;
IF (count_split_int = 0) THEN
	SELECT psa_id,psa_type INTO psa_id_int,psa_type_str
	FROM mstb_project_stage_addtional 
  WHERE pro_id = pro_id_int AND psa_code = sp_psps_code AND psa_type = psa_type_tmp LIMIT 1 ; 
	INSERT INTO mstb_design_split_main (
		pro_id,
		stage_id,
		psa_id,
		psa_code,
		psa_type
	)
	VALUES(
		pro_id_int,
		pst_id_int,
		psa_id_int,
		sp_psps_code,
		psa_type_str
	) ;
	END IF ;
	END;
