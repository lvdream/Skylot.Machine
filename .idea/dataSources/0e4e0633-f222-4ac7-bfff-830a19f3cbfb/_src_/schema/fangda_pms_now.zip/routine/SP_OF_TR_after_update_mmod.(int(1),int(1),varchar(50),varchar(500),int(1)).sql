CREATE PROCEDURE SP_OF_TR_after_update_mmod(IN sp_pro_id    INT(1), IN sp_prv_id INT(1), IN sp_mod_code VARCHAR(50),
                                            IN sp_psam_code VARCHAR(500), IN sp_modd_num INT(1))
  BEGIN
DECLARE mos_design_num_int int(1);
DECLARE mos_ordered_num_int int(1);
DECLARE mos_noordered_num_int int(1);
DECLARE mos_orders_str varchar(2000);
DECLARE mos_status_str varchar(1);

DECLARE flag int DEFAULT 0;

DECLARE cur CURSOR FOR SELECT mos.mos_design_num,mos.mos_ordered_num,mos.mos_orders FROM tstb_material_order_summary mos 
	WHERE mos.pro_id = sp_pro_id AND mos.prv_id = sp_prv_id AND mos.psam_code = sp_psam_code;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;
OPEN cur;
LOOP_LABEL : LOOP
	FETCH cur INTO mos_design_num_int,mos_ordered_num_int,mos_orders_str;
	IF flag = 1 THEN
		LEAVE LOOP_LABEL;
	END IF;
-- 已订购数 = 原有订购数 - 订购数（需要恢复的）
SET mos_ordered_num_int = mos_ordered_num_int - sp_modd_num;
-- 待订购数 = 设计总量 - 已订购数
SET mos_noordered_num_int = mos_design_num_int - mos_ordered_num_int;

-- IF (LOCATE(';',mos_orders_str) = 0) THEN 
-- 	SET mos_orders_str = REPLACE(mos_orders_str,sp_mod_code,'');
-- ELSE 
-- 	SET mos_orders_str = REPLACE(mos_orders_str,CONCAT(sp_mod_code,';'),'');
-- END IF;

SET mos_status_str = '0';
-- 如果设计总量变为0，且订购单记录不为空，那么设置订购状态为“无需订购~设计变更”
IF (mos_design_num_int = 0 AND !ISNULL(mos_orders_str) AND mos_orders_str != '') THEN 
	SET mos_status_str = '3';
END IF;

UPDATE tstb_material_order_summary mos 
	SET mos.mos_ordered_num = mos_ordered_num_int,
		mos.mos_noordered_num = mos_noordered_num_int,
		mos.mos_status = mos_status_str,
		mos.mos_orders = mos_orders_str 
	WHERE mos.pro_id = sp_pro_id AND mos.prv_id = sp_prv_id AND mos.psam_code = sp_psam_code;
END LOOP;
CLOSE cur;
END;
