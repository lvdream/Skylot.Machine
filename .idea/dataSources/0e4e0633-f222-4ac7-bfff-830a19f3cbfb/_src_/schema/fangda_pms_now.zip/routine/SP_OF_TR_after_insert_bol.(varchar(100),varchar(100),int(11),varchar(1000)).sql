CREATE PROCEDURE SP_OF_TR_after_insert_bol(IN sp_bol_table VARCHAR(100), IN sp_bol_column VARCHAR(100),
                                           IN sp_bol_num   INT, IN sp_bol_remark VARCHAR(1000))
  BEGIN
	DECLARE sqlstr varchar(2000);
	-- 拼接SQL语句
	SET sqlstr = CONCAT('UPDATE ',sp_bol_table,' SET ',
		sp_bol_column,' = ',sp_bol_column,' + ',sp_bol_num,
		' WHERE ',sp_bol_remark);
	SET @sql = sqlstr;
	PREPARE presql FROM @sql;
	EXECUTE presql;
	DEALLOCATE PREPARE presql;
END;
