CREATE PROCEDURE SP_insert_tm(IN mes_title        VARCHAR(200), IN mes_content VARCHAR(2000), IN mes_type VARCHAR(1),
                              IN mes_businesstype VARCHAR(50), IN mes_businessid VARCHAR(20),
                              IN mes_receivetype  VARCHAR(50), IN mes_status VARCHAR(1), IN mes_createdate VARCHAR(20),
                              IN mes_createuser   VARCHAR(20), IN mes_updatedate VARCHAR(20),
                              IN mes_updateuser   VARCHAR(20))
  BEGIN

-- 设计单待设计消息隐藏：工程项目中没有设计单处于“设计中”状态
-- 已完成：详见：SP_OF_TR_after_update_mpsa

-- 校对单待校对消息隐藏：工程项目中没有校对单处于“待校对”状态
-- 已完成：详见：SP_OF_TR_after_update_mr

-- 审核单待审核消息隐藏：工程项目中没有审核单处于“待审核”状态
-- 已完成：详见：SP_OF_TR_after_update_mr

-- 校对单、审核单直接驳回：工程项目中没有校对单或审核单处于“直接驳回”状态
-- 已完成：详见：SP_OF_TR_after_update_mr

-- 校对单、审核单弃用驳回：工程项目中所有处于“弃用驳回”状态的校对单或审核单对应的设计单没有处于“设计中”状态
-- 已完成：详见：SP_OF_TR_after_update_mpsa

-- 立面图待上传消息隐藏：工程项目中所有阶段都至少上传了一张立面图
-- 已完成：详见：SP_OF_TR_after_insert_msi_hide

-- 编号图待编辑消息隐藏：工程项目中所有立面图都有相应的编号图
-- 已完成：详见：SP_OF_TR_after_insert_opsps_hide

-- 编号图待重新编辑消息隐藏：？？？

-- 消息记录创建之前，判断某个项目是否有已存在该信息
IF NOT EXISTS(SELECT 1 FROM tstb_message tm 
				WHERE tm.mes_businesstype = mes_businesstype AND tm.mes_businessid = mes_businessid) THEN
	INSERT INTO tstb_message(
		mes_title,
		mes_content,
		mes_type,
		mes_businesstype,
		mes_businessid,
		mes_receivetype,
		mes_status,
		mes_createdate,
		mes_createuser,
		mes_updatedate,
		mes_updateuser) 
	VALUES(
		mes_title,
		mes_content,
		mes_type,
		mes_businesstype,
		mes_businessid,
		mes_receivetype,
		mes_status,
		mes_createdate,
		mes_createuser,
		mes_updatedate,
		mes_updateuser
	);
ELSE 
-- 如果已经存在，那么就将消息状态更新为有效，即使之前已经为有效状态
	UPDATE tstb_message tm SET tm.mes_status = '1' 
		WHERE tm.mes_businesstype = mes_businesstype AND tm.mes_businessid = mes_businessid;
END IF;
END;
