CREATE FUNCTION msfn_check_index_exist_table(in_var_table_name VARCHAR(100), in_var_index_name VARCHAR(100))
  RETURNS INT(1)
  BEGIN
  #create by saul @2016-01-14
  #check the index exist in the target TABLE
  #
	DECLARE
		int_countOfindex INT;

SELECT
	count(*) INTO int_countOfindex
FROM
	`performance_schema`.table_io_waits_summary_by_index_usage
WHERE
	object_name = in_var_table_name

and INDEX_NAME =in_var_index_name;

RETURN int_countOfindex;
END;
