CREATE PROCEDURE SP_OF_TR_after_insert_tm(IN mes_id          INT, IN mes_businessid INT(50),
                                          IN mes_receivetype VARCHAR(100), IN mes_option2 VARCHAR(20))
  BEGIN
DECLARE flag int DEFAULT 0;
DECLARE emp_usercode_str varchar(200);

DECLARE sp_cur CURSOR FOR SELECT sp.usercode FROM mstb_staff_plan sp 
		WHERE sp.pro_id = mes_businessid AND sp.plan_staff_type = mes_receivetype;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;
OPEN sp_cur;
LOOP_LABEL : LOOP
FETCH sp_cur INTO emp_usercode_str;
IF flag = 1 THEN
	LEAVE LOOP_LABEL;
END IF;
    -- 如果指定人员不为空，那么遍历后，只有和指定人员匹配才能执行后续操作 //TODO优化
	IF (mes_option2 != '') THEN 
		SET emp_usercode_str = mes_option2;
		IF NOT EXISTS(SELECT 1 FROM tstb_message_employee tme WHERE tme.mes_id = mes_id AND tme.emp_usercode = emp_usercode_str) THEN
			INSERT INTO tstb_message_employee(mes_id,emp_usercode) VALUES (mes_id,emp_usercode_str);
		END IF;
		LEAVE LOOP_LABEL;-- 指定人员了，那么就只判断一次，提高效率
	END IF;
	IF NOT EXISTS(SELECT 1 FROM tstb_message_employee tme WHERE tme.mes_id = mes_id AND tme.emp_usercode = emp_usercode_str) THEN
		INSERT INTO tstb_message_employee(mes_id,emp_usercode) VALUES (mes_id,emp_usercode_str);
	END IF;
END LOOP;
CLOSE sp_cur;
END;
