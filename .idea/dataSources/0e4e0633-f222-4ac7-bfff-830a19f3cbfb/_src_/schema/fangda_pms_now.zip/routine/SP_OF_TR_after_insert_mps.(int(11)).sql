CREATE PROCEDURE SP_OF_TR_after_insert_mps(IN pro_id INT)
  BEGIN
DECLARE CONSTANT_MES_TYPE_YW varchar(1) DEFAULT '1';-- 消息类型：业务消息
DECLARE CONSTANT_MES_RECEIVETYPE_SJS varchar(50) DEFAULT 'project.plan.sjs';-- 人员类型：设计师
DECLARE CONSTANT_MES_TITLE_LMTSC varchar(50) DEFAULT '立面图待上传';
DECLARE CONSTANT_MESSAGE_LMIMAGE_NEEDUPLOAD varchar(50) DEFAULT 'pms.lmimage.needupload';-- 立面图未上传，请您尽快处理

DECLARE pro_name_str varchar(50);

DECLARE mes_title_str varchar(200);
DECLARE mes_content_str varchar(2000);
DECLARE mes_type_str varchar(1);
DECLARE mes_businesstype_str varchar(30);
DECLARE mes_businessid_str varchar(20);
DECLARE mes_receivetype_str varchar(50);
DECLARE mes_status_str varchar(1);
DECLARE mes_createdate_str varchar(20);
DECLARE mes_createuser_str varchar(20);
DECLARE mes_updatedate_str varchar(20);
DECLARE mes_updateuser_str varchar(20);

SET pro_name_str = (SELECT p.pro_name FROM mstb_project p WHERE p.pro_id = pro_id);

SET mes_title_str = CONSTANT_MES_TITLE_LMTSC;
SET mes_businesstype_str = CONSTANT_MESSAGE_LMIMAGE_NEEDUPLOAD;
SET mes_content_str = (SELECT dic.dic_name FROM cmtb_dictionary dic WHERE dic.dic_code = mes_businesstype_str);
SET mes_content_str = (SELECT REPLACE(mes_content_str,'[pro_name]',pro_name_str));
SET mes_type_str = CONSTANT_MES_TYPE_YW;
SET mes_businessid_str = pro_id;
SET mes_receivetype_str = CONSTANT_MES_RECEIVETYPE_SJS;
SET mes_createdate_str = NOW();
SET mes_createuser_str = 'system';
SET mes_updatedate_str = '';
SET mes_updateuser_str = '';
SET mes_status_str = '1';

-- 消息记录创建之前，判断某个项目是否有已存在该信息
CALL SP_insert_tm(
	mes_title_str,
	mes_content_str,
	mes_type_str,
	mes_businesstype_str,
	mes_businessid_str,
	mes_receivetype_str,
	mes_status_str,
	mes_createdate_str,
	mes_createuser_str,
	mes_updatedate_str,
	mes_updateuser_str
);
END;
