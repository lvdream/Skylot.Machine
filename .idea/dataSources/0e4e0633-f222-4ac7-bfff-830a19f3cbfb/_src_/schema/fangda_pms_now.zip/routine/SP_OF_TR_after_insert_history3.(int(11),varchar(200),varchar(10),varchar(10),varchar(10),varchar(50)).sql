CREATE PROCEDURE SP_OF_TR_after_insert_history3(IN sp_hist_id INT, IN sp_hist_addtional_ids VARCHAR(200),
                                                IN sp_pv_id   VARCHAR(10), IN sp_rev_type VARCHAR(10),
                                                IN sp_status  VARCHAR(10), IN sp_mpp_sureStatus VARCHAR(50))
  BEGIN
 DECLARE
  psam_id_int INT;

DECLARE
 psa_id_int INT;

-- 定义设计单编号
DECLARE
 pro_id_int INT;

DECLARE
 psar_parent_code_str VARCHAR (1000) CHARACTER
SET utf8;

-- 定义设计单编号
DECLARE
 psar_sub_code_str VARCHAR (100) CHARACTER
SET utf8;

-- '子组件ID',
DECLARE
 psam_name_str VARCHAR (200) CHARACTER
SET utf8;

-- '阶段类型名称',
DECLARE
 prv_id_str VARCHAR (100) CHARACTER
SET utf8;

-- '材料名称序号',
DECLARE
 mma_id_str VARCHAR (200) CHARACTER
SET utf8;

--  '物料基本属性序号',
DECLARE
 mpm_id_str VARCHAR (200) CHARACTER
SET utf8;

--  '物料工程属性序号',
DECLARE
 psam_code_str VARCHAR (500) CHARACTER
SET utf8;

-- '材料编号',
DECLARE
 psam_design_size_str VARCHAR (200) CHARACTER
SET utf8;

-- '设计尺寸',
DECLARE
 psam_process_size_str VARCHAR (200) CHARACTER
SET utf8;

-- '加工尺寸',
DECLARE
 psam_tech_requirement_str VARCHAR (500) CHARACTER
SET utf8;

-- '技术要求',
DECLARE
 psam_quantity_str VARCHAR (200) CHARACTER
SET utf8;

-- '数量',
DECLARE
 psam_unit_str VARCHAR (200) CHARACTER
SET utf8;

--  '单位',
DECLARE
 psam_weight_str VARCHAR (200) CHARACTER
SET utf8;

--  '重量（Kg）/面积（m2）',
DECLARE
 psam_description_str VARCHAR (1000) CHARACTER
SET utf8;

-- '备注',
DECLARE
 psam_weight_single_str VARCHAR (200) CHARACTER
SET utf8;

-- '单重（线密度）Kg/m',
DECLARE
 psam_action_area_str VARCHAR (200) CHARACTER
SET utf8;

-- '喷涂面积',
DECLARE
 psam_option1_str VARCHAR (200) CHARACTER
SET utf8;

-- '预留字段1',
DECLARE
 psam_option2_str VARCHAR (1000) CHARACTER
SET utf8;

-- '预留字段2',
DECLARE
 psam_status_str VARCHAR (10) CHARACTER
SET utf8;

-- '材料状态', 
DECLARE
 mpp_sureStatus_str VARCHAR (10) CHARACTER
SET utf8;

-- 颜色是否待定
DECLARE
 psa_code_str VARCHAR (100);

-- 定义设计单号

DECLARE psam_ompName_str VARCHAR(100); -- 工艺图名称
DECLARE psam_option4_str VARCHAR(100); -- 开模图
DECLARE psam_option6_str VARCHAR(100);
DECLARE
 done INT DEFAULT FALSE;

DECLARE
 psam_cur CURSOR FOR SELECT
  `psam_id`,
  `psa_id`,
  `pro_id`,
  `psar_parent_code`,
  `psar_sub_code`,
  `psam_name`,
  `prv_id`,
  `mma_id`,
  `mpm_id`,
  `psam_code`,
  `psam_design_size`,
  `psam_process_size`,
  `psam_tech_requirement`,
  `psam_quantity`,
  `psam_unit`,
  `psam_weight`,
  `psam_description`,
  `psam_weight_single`,
  `psam_action_area`,
  `psam_option1`,
  `psam_option2`,
  `psam_status`,
  `mpp_sureStatus`,
  `psa_code`,
  `psam_ompName`, -- 工艺图名称
  `psam_option4`, -- 开模图名称
	`psam_option6`
 FROM
  `mstb_project_stage_addtional_material`
 WHERE
  prv_id = sp_pv_id
 AND FIND_IN_SET(
  psa_id,
  sp_hist_addtional_ids
 )
 AND psam_status = sp_rev_type
 AND FIND_IN_SET(
  mpp_sureStatus,
  sp_mpp_sureStatus
 )
;

DECLARE
 CONTINUE HANDLER FOR NOT FOUND
SET done = TRUE;

OPEN psam_cur;

pasm_loop :
LOOP
 FETCH psam_cur INTO psam_id_int,
 psa_id_int,
 pro_id_int,
 psar_parent_code_str,
 psar_sub_code_str,
 psam_name_str,
 prv_id_str,
 mma_id_str,
 mpm_id_str,
 psam_code_str,
 psam_design_size_str,
 psam_process_size_str,
 psam_tech_requirement_str,
 psam_quantity_str,
 psam_unit_str,
 psam_weight_str,
 psam_description_str,
 psam_weight_single_str,
 psam_action_area_str,
 psam_option1_str,
 psam_option2_str,
 psam_status_str,
 mpp_sureStatus_str,
 psa_code_str,
 psam_ompName_str,
 psam_option4_str,
 psam_option6_str;


IF done THEN
 LEAVE pasm_loop;


END
IF;

INSERT INTO `mstb_material_history` (
 `hist_id`,
 `psam_id`,
 `psa_id`,
 `pro_id`,
 `psar_parent_code`,
 `psar_sub_code`,
 `psam_name`,
 `prv_id`,
 `mma_id`,
 `mpm_id`,
 `psam_code`,
 `psam_design_size`,
 `psam_process_size`,
 `psam_tech_requirement`,
 `psam_quantity`,
 `psam_unit`,
 `psam_weight`,
 `psam_description`,
 `psam_weight_single`,
 `psam_action_area`,
 `psam_option1`,
 `psam_option2`,
 `psam_status`,
 `mpp_sureStatus`,
 `psa_code`,
 `backup1`,
 `backup2`,
 `backup3`
)
VALUES
 (
  sp_hist_id,
  psam_id_int,
  psa_id_int,
  pro_id_int,
  psar_parent_code_str,
  psar_sub_code_str,
  psam_name_str,
  prv_id_str,
  mma_id_str,
  mpm_id_str,
  psam_code_str,
  psam_design_size_str,
  psam_process_size_str,
  psam_tech_requirement_str,
  psam_quantity_str,
  psam_unit_str,
  psam_weight_str,
  psam_description_str,
  psam_weight_single_str,
  psam_action_area_str,
  psam_option1_str,
  psam_option2_str,
  psam_status_str,
  mpp_sureStatus_str,
  psa_code_str,
  psam_ompName_str,
  psam_option4_str,
	psam_option6_str
 );


END
LOOP
;

CLOSE psam_cur;

UPDATE mstb_project_stage_addtional_material
SET psam_status = sp_status
WHERE
 prv_id = sp_pv_id
AND FIND_IN_SET(
 mpp_sureStatus,
 sp_mpp_sureStatus
)
AND FIND_IN_SET(
 psa_id,
 sp_hist_addtional_ids
)
AND psam_status = sp_rev_type
AND !ISNULL(psam_process_size)
;


END;
