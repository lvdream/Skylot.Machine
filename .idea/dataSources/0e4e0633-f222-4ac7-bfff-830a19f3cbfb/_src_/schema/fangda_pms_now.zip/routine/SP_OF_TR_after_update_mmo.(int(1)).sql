CREATE PROCEDURE SP_OF_TR_after_update_mmo(IN sp_mod_id INT(1))
  BEGIN
	UPDATE mstb_material_order_detail modd SET modd.modd_status = '0' WHERE modd.mod_id = sp_mod_id;
END;
