CREATE PROCEDURE SP_OF_TR_after_insert_opsps_hide(IN sp_image_id INT)
  BEGIN
DECLARE pro_id_int int;
DECLARE stage_id_int int;
DECLARE image_id_int int;
DECLARE hide_flag int DEFAULT 1; -- 默认隐藏
DECLARE mes_businesstype_str varchar(50);
DECLARE CONSTANT_STAGE_STRUCTURE_TYPE_DYS varchar(1) DEFAULT '1';-- 结构类型：单元式
DECLARE CONSTANT_MESSAGE_LMIMAGE_NEEDUPLOAD varchar(50) DEFAULT 'pms.lmimage.needupload';-- 立面图未上传，请您尽快处理
DECLARE CONSTANT_MESSAGE_BHIMAGE_NEEDUPLOAD varchar(50) DEFAULT 'pms.bhimage.needupload';-- 编号图未编辑，请您尽快处理
DECLARE CONSTANT_MESSAGE_BHIMAGE_NEEDUPDATE varchar(50) DEFAULT 'pms.bhimage.needupdate';-- 设计师更新了立面图，请重新编辑编号图

DECLARE count int;
DECLARE flag int DEFAULT 0;

-- 根据立面图ID查找工程项目ID和阶段类型
SET pro_id_int := (SELECT ps.pro_id FROM mstb_project_stage ps 
	JOIN (
		SELECT msi.stage_id FROM mstb_stage_image msi WHERE msi.image_id = sp_image_id
	) tmp 
	ON ps.stage_id = tmp.stage_id);

BEGIN
-- 查找出工程项目中所有阶段
DECLARE cur CURSOR FOR SELECT ps.stage_id FROM mstb_project_stage ps WHERE ps.pro_id = pro_id_int;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET flag = 1;
OPEN cur;
LOOP_LABEL : LOOP
	FETCH cur INTO stage_id_int;
	IF flag = 1 THEN 
		LEAVE LOOP_LABEL;
	END IF;
	-- 是否每个阶段中每张立面图都有对应的立面编号图与之对应
	BEGIN
	DECLARE inner_flag int DEFAULT 0;
	
	DECLARE inner_cur CURSOR FOR SELECT msi.image_id FROM mstb_stage_image msi WHERE msi.stage_id = stage_id_int;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET inner_flag = 1;
	OPEN inner_cur;
	INNER_LOOP_LABEL : LOOP
		FETCH inner_cur INTO image_id_int;
		IF inner_flag = 1 THEN 
			LEAVE INNER_LOOP_LABEL;
		END IF;
		SET count = (SELECT COUNT(*) FROM oftb_project_stage_plate_summary psps WHERE psps.image_id = image_id_int);
		IF (count = 0) THEN 
			SET hide_flag = 0;
			LEAVE INNER_LOOP_LABEL;
		END IF; 
	END LOOP;
	CLOSE inner_cur;
	END;
END LOOP;
CLOSE cur;
IF (hide_flag = 1) THEN 
	SET mes_businesstype_str = CONSTANT_MESSAGE_LMIMAGE_NEEDUPLOAD;
END IF;
UPDATE tstb_message tm SET tm.mes_status = '0' 
	WHERE tm.mes_businesstype = mes_businesstype_str AND tm.mes_businessid = pro_id_int;
END;
END;
