CREATE TRIGGER TR_after_insert_mstb_review_history
AFTER INSERT ON mstb_review_history
FOR EACH ROW
  BEGIN

END;
