CREATE TRIGGER TR_after_insert_tstb_process_material_no
BEFORE INSERT ON tstb_process_material_no
FOR EACH ROW
  BEGIN
  DECLARE max_count INT; 

  SET max_count = (
    SELECT
      COUNT(*)
    FROM
      tstb_process_material_no b
    WHERE
      b.pro_id = NEW.pro_id AND b.psam_code = NEW.psam_code
  ); 
  SET NEW.pmn_no = CONCAT(CONCAT(NEW.psam_code,'-'),LPAD(max_count + 1, 3, 0)); 
END;
