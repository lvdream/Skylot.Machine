CREATE TRIGGER TR_after_update_mstb_material_order_detail
AFTER UPDATE ON mstb_material_order_detail
FOR EACH ROW
  BEGIN

  SET @pro_id = NEW.pro_id; 
  SET @prv_id = NEW.prv_id; 
  SET @mod_code = NEW.mod_code; 
  SET @psam_code = NEW.psam_code; 
  SET @modd_num = NEW.modd_num; 

  CALL SP_OF_TR_after_update_mmod(@pro_id,@prv_id,@mod_code,@psam_code,@modd_num); 

END;
