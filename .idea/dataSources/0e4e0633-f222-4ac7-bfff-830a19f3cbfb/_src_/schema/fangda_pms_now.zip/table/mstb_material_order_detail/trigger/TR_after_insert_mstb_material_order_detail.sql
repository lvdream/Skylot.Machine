CREATE TRIGGER TR_after_insert_mstb_material_order_detail
AFTER INSERT ON mstb_material_order_detail
FOR EACH ROW
  BEGIN
  SET @pro_id = NEW.pro_id; 
  SET @prv_id = NEW.prv_id; 
  SET @psam_code = NEW.psam_code; 
  SET @mod_code = NEW.mod_code; 

  CALL SP_OF_TR_after_insert_mmod(
      @pro_id,
      @prv_id,
      @psam_code,
      @mod_code
  ); 
END;
