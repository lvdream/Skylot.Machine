CREATE TRIGGER TR_before_insert_mstb_plate_history
BEFORE INSERT ON mstb_plate_history
FOR EACH ROW
  BEGIN
  DECLARE psa_id_int int(11); 
  DECLARE pro_id_int int(1); 
  DECLARE pst_id_int int(11); 
  DECLARE psa_name_str VARCHAR(200); 
  DECLARE psa_code_str VARCHAR(100); 
  DECLARE psa_type_str VARCHAR(2); 
  DECLARE psa_backup_description_str VARCHAR(20); 
  DECLARE psa_size_str VARCHAR(50); 
  DECLARE psa_detail_size_str VARCHAR(250); 
  DECLARE psa_component_area_str VARCHAR(10); 
  DECLARE psa_action_area_str VARCHAR(20); 
  DECLARE psa_startdate_str VARCHAR(20); 
  DECLARE psa_enddate_str VARCHAR(20); 
  DECLARE psa_reviewuser_str VARCHAR(20); 
  DECLARE psa_reviewdate_str VARCHAR(20); 
  DECLARE psa_approvaluser_str VARCHAR(20); 
  DECLARE psa_approvaldate_str VARCHAR(20); 
  DECLARE psa_description_str VARCHAR(500); 
  DECLARE psa_status_str VARCHAR(2); 
  DECLARE psa_sub_status_one_str VARCHAR(1); 
  DECLARE psa_sub_status_two_str VARCHAR(1); 
  DECLARE psa_sub_status_three_str VARCHAR(1); 
  DECLARE psa_sub_status_four_str VARCHAR(1); 
  DECLARE psa_img_one_str VARCHAR(255); 
  DECLARE psa_img_two_str VARCHAR(255); 
  DECLARE psa_img_three_str VARCHAR(255); 
  DECLARE psa_createdate_str VARCHAR(20); 
  DECLARE psa_createuser_str VARCHAR(20); 
  DECLARE psa_updatedate_str VARCHAR(20); 
  DECLARE psa_updateuser_str VARCHAR(20); 
  DECLARE psa_option1_str VARCHAR(20); 
  DECLARE psa_option2_str VARCHAR(20); 
  DECLARE psa_option3_str VARCHAR(2000); 
  DECLARE psa_cur CURSOR FOR
    SELECT
      psa_id,
      pro_id,
      pst_id,
      psa_name,
      psa_code,
      psa_type,
      psa_backup_description,
      psa_size,
      psa_detail_size,
      psa_component_area,
      psa_action_area,
      psa_startdate,
      psa_enddate,
      psa_reviewuser,
      psa_reviewdate,
      psa_approvaluser,
      psa_approvaldate,
      psa_description,
      psa_status,
      psa_sub_status_one,
      psa_sub_status_two,
      psa_sub_status_three,
      psa_sub_status_four,
      psa_img_one,
      psa_img_two,
      psa_img_three,
      psa_createdate,
      psa_createuser,
      psa_updatedate,
      psa_updateuser,
      psa_option1,
      psa_option2,
      psa_option3
    FROM
      mstb_project_stage_addtional
    WHERE
      psa_id = NEW.psa_id AND NEW.psa_is_update = '0'; 

  IF NEW.psa_is_update ='0' THEN
    OPEN psa_cur; 
    FETCH psa_cur INTO
      psa_id_int,
      pro_id_int,
      pst_id_int,
      psa_name_str,
      psa_code_str,
      psa_type_str,
      psa_backup_description_str,
      psa_size_str,
      psa_detail_size_str,
      psa_component_area_str,
      psa_action_area_str,
      psa_startdate_str,
      psa_enddate_str,
      psa_reviewuser_str,
      psa_reviewdate_str,
      psa_approvaluser_str,
      psa_approvaldate_str,
      psa_description_str,
      psa_status_str,
      psa_sub_status_one_str,
      psa_sub_status_two_str,
      psa_sub_status_three_str,
      psa_sub_status_four_str,
      psa_img_one_str,
      psa_img_two_str,
      psa_img_three_str,
      psa_createdate_str,
      psa_createuser_str,
      psa_updatedate_str,
      psa_updateuser_str,
      psa_option1_str,
      psa_option2_str,
      psa_option3_str; 
    SET NEW.psa_id = psa_id_int; 
    SET NEW.pro_id = pro_id_int; 
    SET NEW.pst_id = pst_id_int; 
    SET NEW.psa_name = psa_name_str; 
    SET NEW.psa_code = psa_code_str; 
    SET NEW.psa_type = psa_type_str; 
    SET NEW.psa_backup_description = psa_backup_description_str; 
    SET NEW.psa_size = psa_size_str; 
    SET NEW.psa_detail_size = psa_detail_size_str; 
    SET NEW.psa_component_area = psa_component_area_str; 
    SET NEW.psa_action_area = psa_action_area_str; 
    SET NEW.psa_startdate = psa_startdate_str; 
    SET NEW.psa_enddate = psa_enddate_str; 
    SET NEW.psa_reviewuser = psa_reviewuser_str; 
    SET NEW.psa_reviewdate = psa_reviewdate_str; 
    SET NEW.psa_approvaluser = psa_approvaluser_str; 
    SET NEW.psa_approvaldate = psa_approvaldate_str; 
    SET NEW.psa_description = psa_description_str; 
    SET NEW.psa_status = psa_status_str; 
    SET NEW.psa_sub_status_one = psa_sub_status_one_str; 
    SET NEW.psa_sub_status_two = psa_sub_status_two_str; 
    SET NEW.psa_sub_status_three = psa_sub_status_three_str; 
    SET NEW.psa_sub_status_four = psa_sub_status_four_str; 
    SET NEW.psa_img_one = psa_img_one_str; 
    SET NEW.psa_img_two = psa_img_two_str; 
    SET NEW.psa_img_three = psa_img_three_str; 
    SET NEW.psa_createdate = psa_createdate_str; 
    SET NEW.psa_createuser = psa_createuser_str; 
    SET NEW.psa_updatedate = psa_updatedate_str; 
    SET NEW.psa_updateuser = psa_updateuser_str; 
    SET NEW.psa_option1 = psa_option1_str; 
    SET NEW.psa_option2 = psa_option2_str; 
    SET NEW.psa_option3 = psa_option3_str; 

    CLOSE psa_cur; 
  END IF; 
END;
