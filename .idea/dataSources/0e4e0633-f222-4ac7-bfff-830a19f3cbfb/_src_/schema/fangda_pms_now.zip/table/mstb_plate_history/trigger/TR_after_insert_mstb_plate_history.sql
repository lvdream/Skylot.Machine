CREATE TRIGGER TR_after_insert_mstb_plate_history
AFTER INSERT ON mstb_plate_history
FOR EACH ROW
  BEGIN
  -- relationship columns 
  DECLARE psar_id_int INT(11); 
  DECLARE psa_id_int INT(11); 
  DECLARE psar_parent_code_str VARCHAR(100); 
  DECLARE psar_code_str VARCHAR(100); 
  DECLARE psar_name_str VARCHAR(200); 
  DECLARE psar_size_str VARCHAR(200); 
  DECLARE psar_quantity_str VARCHAR(20); 
  DECLARE psar_description_str VARCHAR(200); 
  DECLARE psar_status_str VARCHAR(1); 
  DECLARE psar_img_one_str VARCHAR(255); 
  DECLARE psar_img_two_str VARCHAR(255); 
  DECLARE psar_img_three_str VARCHAR(255); 
  DECLARE psar_createuser_str VARCHAR(20); 
  DECLARE psar_createdate_str VARCHAR(20); 
  DECLARE psar_updateuser_str VARCHAR(20); 
  DECLARE psar_updatedate_str VARCHAR(20); 

  -- material columns 
  DECLARE psam_id_int INT(11); 
  DECLARE pro_id_int INT(11); 
  DECLARE psam_code_str VARCHAR (200); 
  DECLARE psa_code_str VARCHAR (100); 
  DECLARE psar_sub_code_str VARCHAR (100); 
  DECLARE psam_name_str VARCHAR (200); 
  DECLARE prv_id_str VARCHAR (2); 
  DECLARE mma_id_str VARCHAR (255); 
  DECLARE mpm_id_str VARCHAR (100); 
  DECLARE psam_weight_single_str VARCHAR (255); 
  DECLARE psam_action_area_str VARCHAR (255); 
  DECLARE psam_design_size_str VARCHAR (200); 
  DECLARE psam_process_size_str VARCHAR (200); 
  DECLARE psam_tech_requirement_str VARCHAR (500); 
  DECLARE psam_quantity_str VARCHAR (20); 
  DECLARE psam_unit_str VARCHAR (20); 
  DECLARE psam_weight_str VARCHAR (20); 
  DECLARE psam_description_str VARCHAR (200); 
  DECLARE psam_option1_str VARCHAR (100); 
  DECLARE psam_option2_str VARCHAR (255); 
  DECLARE psam_option3_str VARCHAR (200); 
  DECLARE psam_ompName_str VARCHAR(100); 
  DECLARE psam_option4_str VARCHAR(100); 
  DECLARE psam_option5_str VARCHAR(100); 
  DECLARE psam_option6_str VARCHAR(10); 
  DECLARE psam_option7_str VARCHAR(2); 
  DECLARE psam_createdate_str VARCHAR (20); 
  DECLARE psam_createuser_str VARCHAR (20); 
  DECLARE psam_updatedate_str VARCHAR (20); 
  DECLARE psam_updateuser_str VARCHAR (20); 
  DECLARE psam_status_str VARCHAR (10); 

  DECLARE done INT DEFAULT FALSE; 
  DECLARE psar_cur CURSOR FOR
    SELECT
      psar_id,
      psa_id,
      psar_name,
      psar_parent_code,
      psar_code,
      psar_size,
      psar_quantity,
      psar_description,
      psar_status,
      psar_img_one,
      psar_img_two,
      psar_img_three,
      psar_createuser_str,
      psar_createdate_str,
      psar_updateuser_str,
      psar_updatedate_str
    FROM
      mstb_project_stage_addtional_relationship
    WHERE
      psa_id = NEW.psa_id; 

  DECLARE psam_cur CURSOR FOR
    SELECT
      psam_id,
      psam_code,
      pro_id,
      psa_id,
      psa_code,
      psar_parent_code,
      psar_sub_code,
      psam_name,
      prv_id,
      mma_id,
      mpm_id,
      psam_weight_single,
      psam_action_area,
      psam_design_size,
      psam_process_size,
      psam_tech_requirement,
      psam_quantity,
      psam_unit,
      psam_weight,
      psam_description,
      psam_option1,
      psam_option2,
      psam_ompName,
      psam_option3,
      psam_option4,
      psam_option5,
      psam_option6,
      psam_option7,
      psam_createdate,
      psam_createuser,
      psam_updatedate,
      psam_updateuser,
      psam_status
    FROM
      mstb_project_stage_addtional_material
    WHERE
      psa_id = NEW.psa_id; 

  DECLARE CONTINUE HANDLER FOR NOT FOUND
  SET done = TRUE; 
  IF NEW.psa_is_update = '0' THEN
    -- 遍历relationship columns
    OPEN psar_cur; 
    pasr_loop : LOOP
      FETCH psar_cur INTO
        psar_id_int,
        psa_id_int,
        psar_name_str,
        psar_parent_code_str,
        psar_code_str,
        psar_size_str,
        psar_quantity_str,
        psar_description_str,
        psar_status_str,
        psar_img_one_str,
        psar_img_two_str,
        psar_img_three_str,
        psar_createuser_str,
        psar_createdate_str,
        psar_updateuser_str,
        psar_updatedate_str; 
      IF done THEN
        LEAVE pasr_loop; 
      END IF; 

      INSERT INTO mstb_relationship_history (
        hist_id,
        psar_id,
        psa_id,
        psar_name,
        psar_parent_code,
        psar_code,
        psar_size,
        psar_quantity,
        psar_description,
        psar_status,
        psar_img_one,
        psar_img_two,
        psar_img_three,
        psar_createuser,
        psar_createdate,
        psar_updateuser,
        psar_updatedate
      )
      VALUES(
        NEW.hist_id,
        psar_id_int,
        psa_id_int,
        psar_name_str,
        psar_parent_code_str,
        psar_code_str,
        psar_size_str,
        psar_quantity_str,
        psar_description_str,
        psar_status_str,
        psar_img_one_str,
        psar_img_two_str,
        psar_img_three_str,
        psar_createuser_str,
        psar_createdate_str,
        psar_updateuser_str,
        psar_updatedate_str
      ); 
    END LOOP; 
    CLOSE psar_cur; 

    -- 遍历material columns
    SET done = FALSE; 

    OPEN psam_cur; 
    pasm_loop : LOOP
      FETCH psam_cur INTO
        psam_id_int,
        psam_code_str,
        pro_id_int,
        psa_id_int,
        psa_code_str,
        psar_parent_code_str,
        psar_sub_code_str,
        psam_name_str,
        prv_id_str,
        mma_id_str,
        mpm_id_str,
        psam_weight_single_str,
        psam_action_area_str,
        psam_design_size_str,
        psam_process_size_str,
        psam_tech_requirement_str,
        psam_quantity_str,
        psam_unit_str,
        psam_weight_str,
        psam_description_str,
        psam_option1_str,
        psam_option2_str,
        psam_ompName_str,
        psam_option3_str,
        psam_option4_str,
        psam_option5_str,
        psam_option6_str,
        psam_option7_str,
        psam_createdate_str,
        psam_createuser_str,
        psam_updatedate_str,
        psam_updateuser_str,
        psam_status_str; 
      IF done THEN
        LEAVE pasm_loop; 
      END IF; 

      INSERT INTO mstb_material_history (
        hist_id,
        psam_id,
        psam_code,
        pro_id,
        psa_id,
        psa_code,
        psar_parent_code,
        psar_sub_code,
        psam_name,
        prv_id,
        mma_id,
        mpm_id,
        psam_weight_single,
        psam_action_area,
        psam_design_size,
        psam_process_size,
        psam_tech_requirement,
        psam_quantity,
        psam_unit,
        psam_weight,
        psam_description,
        psam_option1,
        psam_option2,
        backup1,
        psam_option3,
        psam_option4,
        psam_option5,
        psam_option6,
        psam_option7,
        backup2,
        backup3,
        psam_createdate,
        psam_createuser,
        psam_updatedate,
        psam_updateuser,
        psam_status
      )
      VALUES(
        NEW.hist_id,
        psam_id_int,
        psam_code_str,
        pro_id_int,
        psa_id_int,
        psa_code_str,
        psar_parent_code_str,
        psar_sub_code_str,
        psam_name_str,
        prv_id_str,
        mma_id_str,
        mpm_id_str,
        psam_weight_single_str,
        psam_action_area_str,
        psam_design_size_str,
        psam_process_size_str,
        psam_tech_requirement_str,
        psam_quantity_str,
        psam_unit_str,
        psam_weight_str,
        psam_description_str,
        psam_option1_str,
        psam_option2_str,
        psam_ompName_str,
        psam_option3_str,
        psam_option4_str,
        psam_option5_str,
        psam_option6_str,
        psam_option7_str,
        psam_option4_str,
        psam_option6_str,
        psam_createdate_str,
        psam_createuser_str,
        psam_updatedate_str,
        psam_updateuser_str,
        psam_status_str
      ); 

    END LOOP; 
    CLOSE psam_cur; 
  END IF; 
END;
