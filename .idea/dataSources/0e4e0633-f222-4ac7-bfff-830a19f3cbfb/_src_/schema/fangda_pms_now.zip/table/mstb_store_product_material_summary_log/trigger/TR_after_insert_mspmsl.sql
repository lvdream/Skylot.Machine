CREATE TRIGGER TR_after_insert_mspmsl
AFTER INSERT ON mstb_store_product_material_summary_log
FOR EACH ROW
  BEGIN

  IF (NEW.spmsl_operation = 0) THEN

    IF NOT EXISTS(SELECT 1 FROM mstb_store_product_material_summary spms
    WHERE spms.pro_id = NEW.pro_id AND spms.pst_id = NEW.pst_id
          AND spms.psa_id = NEW.psa_id AND spms.psam_id = NEW.psam_id) THEN
      INSERT INTO mstb_store_product_material_summary(
        pro_id,
        pst_id,
        psa_id,
        psa_code,
        psa_name,
        psa_type,
        psam_id,
        psam_code,
        psam_name,
        prv_id,
        spms_hadinstore_num,
        spms_updateuser,
        spms_updatedate
      ) VALUES (
        NEW.pro_id,
        NEW.pst_id,
        NEW.psa_id,
        NEW.psa_code,
        NEW.psa_name,
        NEW.psa_type,
        NEW.psam_id,
        NEW.psam_code,
        NEW.psam_name,
        NEW.prv_id,
        NEW.spmsl_storenum,
        NEW.spmsl_createuser,
        NEW.spmsl_createdate
      ); 
    ELSE
      UPDATE mstb_store_product_material_summary
      SET spms_hadinstore_num = spms_hadinstore_num + (NEW.spmsl_storenum),
        spms_updatedate = NEW.spmsl_createdate,
        spms_updateuser = NEW.spmsl_createuser
      WHERE pro_id = NEW.pro_id AND pst_id = NEW.pst_id
            AND psa_id = NEW.psa_id AND psam_id = NEW.psam_id; 
    END IF; 

  ELSEIF(NEW.spmsl_operation = 1) THEN
    UPDATE mstb_store_product_material_summary
    SET spms_hadoutstore_num = spms_hadoutstore_num + (NEW.spmsl_storenum),
      spms_updatedate = NEW.spmsl_createdate,
      spms_updateuser = NEW.spmsl_createuser
    WHERE pro_id = NEW.pro_id AND pst_id = NEW.pst_id
          AND psa_id = NEW.psa_id AND psam_id = NEW.psam_id; 

  ELSEIF(NEW.spmsl_operation = 2) THEN
    UPDATE mstb_store_product_material_summary
    SET spms_bookoutstore_num = spms_bookoutstore_num + (NEW.spmsl_storenum),
      spms_updatedate = NEW.spmsl_createdate,
      spms_updateuser = NEW.spmsl_createuser
    WHERE pro_id = NEW.pro_id AND pst_id = NEW.pst_id
          AND psa_id = NEW.psa_id AND psam_id = NEW.psam_id; 
  END IF; 
END;
