CREATE TRIGGER TR_after_insert_mstb_material_order
AFTER INSERT ON mstb_material_order
FOR EACH ROW
  BEGIN
  SET @pro_id = NEW.pro_id; 
  SET @prv_id = NEW.prv_id; 
  SET @mod_id = NEW.mod_id; 
  SET @mod_code = NEW.mod_code; 
  SET @mod_createuser = NEW.mod_createuser; 
  SET @mod_createdate = NEW.mod_createdate; 
  SET @mod_updateuser = NEW.mod_updateuser; 
  SET @mod_updatedate = NEW.mod_updatedate; 

  CALL SP_OF_TR_after_insert_mmo(
      @pro_id,
      @prv_id,
      @mod_id,
      @mod_code,
      @mod_createuser,
      @mod_createdate,
      @mod_updateuser,
      @mod_updatedate
  ); 
END;
