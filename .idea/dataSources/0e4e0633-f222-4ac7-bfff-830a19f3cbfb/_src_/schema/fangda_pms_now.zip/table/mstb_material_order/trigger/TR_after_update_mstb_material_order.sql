CREATE TRIGGER TR_after_update_mstb_material_order
AFTER UPDATE ON mstb_material_order
FOR EACH ROW
  BEGIN
  SET @mod_id = NEW.mod_id; 

  CALL SP_OF_TR_after_update_mmo(@mod_id); 

END;
