CREATE TRIGGER TR_before_insert_mstb_material_order
BEFORE INSERT ON mstb_material_order
FOR EACH ROW
  BEGIN
  DECLARE last_mod_code_num VARCHAR(50); 

  SET last_mod_code_num := (SELECT TRIM(LEADING '0' FROM SUBSTRING_INDEX(mod_code,'.',-1))
                            FROM mstb_material_order
                            WHERE pro_id=NEW.pro_id AND prv_id=NEW.prv_id
                            ORDER BY mod_id DESC LIMIT 1); 

  IF FN_IsNum(last_mod_code_num) = 0 THEN
    SET NEW.mod_code := CONCAT(NEW.mod_code,'0001'); 
  ELSE
    SET NEW.mod_code := CONCAT(NEW.mod_code,LPAD(last_mod_code_num + 1, 4, 0)); 
  END IF; 
END;
