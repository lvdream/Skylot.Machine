CREATE TRIGGER TR_after_update_mstb_store_material_site_instore_detail
AFTER UPDATE ON mstb_store_material_site_instore_detail
FOR EACH ROW
  BEGIN

  DECLARE can_count_int INT; 
  DECLARE order_number_int INT; 
  DECLARE o_instore_num_int INT ; 

  IF(NEW.sid_num != OLD.sid_num)THEN
    SET can_count_int = NEW.sid_num - OLD.sid_num; 
    SELECT mpom_purchaseNumber,mpom_hasReceiving_count INTO order_number_int,o_instore_num_int FROM mstb_purchase_order_material WHERE mpom_id = NEW.mpom_id; 

    IF(order_number_int - (o_instore_num_int + (can_count_int)) > 0)THEN
      UPDATE mstb_purchase_order_material SET mpom_status = '4',mpom_hasReceiving_count = mpom_hasReceiving_count + (can_count_int) WHERE mpom_id = NEW.mpom_id; 
    ELSE
      UPDATE mstb_purchase_order_material SET mpom_status = '2',mpom_hasReceiving_count = mpom_hasReceiving_count + (can_count_int) WHERE mpom_id = NEW.mpom_id; 
    END IF; 

  END IF; 
END;
