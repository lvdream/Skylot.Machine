CREATE TRIGGER TR_before_insert_mstb_store_material_unqualified
BEFORE INSERT ON mstb_store_material_unqualified
FOR EACH ROW
  BEGIN
  DECLARE max_count int; 
  SET max_count := (SELECT COUNT(*) FROM mstb_store_material_unqualified WHERE pro_id = NEW.pro_id AND smu_code like CONCAT(NEW.smu_code,'%')); 
  SET NEW.smu_code = CONCAT(NEW.smu_code,LPAD(max_count+1, 3, 0)); 
END;
