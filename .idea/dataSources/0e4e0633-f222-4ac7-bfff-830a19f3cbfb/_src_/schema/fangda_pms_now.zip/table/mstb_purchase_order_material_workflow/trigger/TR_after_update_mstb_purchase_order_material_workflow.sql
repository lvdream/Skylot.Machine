CREATE TRIGGER TR_after_update_mstb_purchase_order_material_workflow
AFTER UPDATE ON mstb_purchase_order_material_workflow
FOR EACH ROW
  BEGIN
  DECLARE total_count_int INT; 
  DECLARE count_instoring_int INT; 
  DECLARE count_instored_int INT; 


  IF(old.mpom_status!=new.mpom_status AND new.mpom_status!='3')THEN
    SET count_instored_int=(SELECT COUNT(1) FROM mstb_purchase_order_material
    WHERE mpom_o_id=new.mpom_o_id AND mpom_status='2'); 
    SET total_count_int=(SELECT COUNT(1) FROM mstb_purchase_order_material
    WHERE mpom_o_id=new.mpom_o_id ); 
    IF(count_instored_int=total_count_int)THEN
      UPDATE mstb_purchase_order_main SET o_status='2' WHERE o_id=new.mpom_o_id; 
    ELSE
      UPDATE mstb_purchase_order_main SET o_status='4' WHERE o_id=new.mpom_o_id; 
    END IF; 
  END IF; 
END;
