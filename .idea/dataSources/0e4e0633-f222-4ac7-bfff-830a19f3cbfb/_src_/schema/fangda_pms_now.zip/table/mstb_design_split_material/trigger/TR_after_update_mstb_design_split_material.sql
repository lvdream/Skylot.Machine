CREATE TRIGGER TR_after_update_mstb_design_split_material
AFTER UPDATE ON mstb_design_split_material
FOR EACH ROW
  BEGIN
  DECLARE count INT; 
  -- 分单材料状态从“其他状态”变成“已分单”状态
  IF (OLD.mdsm_status != '2' AND NEW.mdsm_status = '2') THEN
    CALL SP_OF_TR_after_update_split_for_purchase (
        NEW.mdsm_id,
        NEW.dsm_id,
        NEW.mdsm_purchase_type,
        NEW.mdsm_optimize_type,
        NEW.psam_id
    ); 
    SET count = (SELECT COUNT(*) FROM mstb_design_split_material WHERE dsm_id = NEW.dsm_id AND mdsm_status in ('0','1')); 
    IF (count = 0) THEN
      UPDATE mstb_design_split_main SET dsm_status = '2' WHERE dsm_id = NEW.dsm_id; 
    END IF; 
  END IF; 
END;
