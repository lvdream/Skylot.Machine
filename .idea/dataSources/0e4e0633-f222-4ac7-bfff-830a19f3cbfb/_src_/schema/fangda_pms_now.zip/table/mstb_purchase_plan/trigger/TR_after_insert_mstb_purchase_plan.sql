CREATE TRIGGER TR_after_insert_mstb_purchase_plan
AFTER INSERT ON mstb_purchase_plan
FOR EACH ROW
  BEGIN
  DECLARE done INT DEFAULT FALSE; 
  DECLARE psa_code_str VARCHAR (100); 
  DECLARE psam_id_int INT; 
  DECLARE stage_id_int INT; 
  DECLARE ippm_total_int INT; 
  DECLARE tps_design_num_int INT; 
  DECLARE tps_id_int INT; 
  DECLARE ippm_cur CURSOR FOR SELECT
                                tps_id,
                                psa_code,
                                psam_id,
                                tps_unpurchased_num,
                                stage_id,
                                tps_design_num
                              FROM
                                tstb_purchaseplan_summary
                              WHERE
                                FIND_IN_SET(tps_id, NEW.tps_ids); 

  DECLARE CONTINUE HANDLER FOR NOT FOUND
  SET done = TRUE; 
  OPEN ippm_cur; 
  ippm_loop :
  LOOP
    FETCH ippm_cur INTO tps_id_int,
      psa_code_str,
      psam_id_int,
      ippm_total_int,
      stage_id_int,
      tps_design_num_int; 
    IF done THEN
      LEAVE ippm_loop; 
    END
    IF; 

    INSERT INTO mstb_purchase_plan_material (
      mpp_id,
      psam_id,
      mppm_total,
      psa_code,
      stage_id,
      mppm_status
    )
    VALUES
      (
        NEW.mpp_id,
        psam_id_int,
        ippm_total_int,
        psa_code_str,
        stage_id_int,
        '1'
      ); 

    UPDATE tstb_purchaseplan_summary
    SET tps_purchased_num = tps_purchased_num + ippm_total_int,tps_unpurchased_num = 0,tps_status = '2'
    WHERE tps_id = tps_id_int; 
  END
  LOOP; 
  CLOSE ippm_cur; 
END;
