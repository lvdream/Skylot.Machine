CREATE TRIGGER TR_before_insert_mstb_purchase_plan
BEFORE INSERT ON mstb_purchase_plan
FOR EACH ROW
  BEGIN
  DECLARE max_count INT; 
  SET max_count := (
    SELECT COUNT(*) FROM mstb_purchase_plan b WHERE b.pv_id = NEW.pv_id AND b.stage_id = NEW.stage_id
  ); 
  SET NEW.mpp_no = CONCAT(NEW.mpp_no,LPAD(max_count + 1, 3, 0)); 
END;
