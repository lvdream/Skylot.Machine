CREATE TRIGGER TR_before_insert_mstb_project_stage
BEFORE INSERT ON mstb_project_stage
FOR EACH ROW
  BEGIN
  DECLARE lev_count_int INT; 
  SET lev_count_int = (SELECT COUNT(1) FROM mstb_project_stage WHERE pro_id=new.pro_id); 
  SET new.stage_level=(lev_count_int+1); 
END;
