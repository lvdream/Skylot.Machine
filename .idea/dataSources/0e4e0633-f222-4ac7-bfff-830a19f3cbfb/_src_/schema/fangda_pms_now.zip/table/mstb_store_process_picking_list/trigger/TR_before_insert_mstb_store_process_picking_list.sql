CREATE TRIGGER TR_before_insert_mstb_store_process_picking_list
BEFORE INSERT ON mstb_store_process_picking_list
FOR EACH ROW
  BEGIN
  DECLARE max_count int; 
  IF (new.msppl_type != '1') THEN

    SET max_count :=(SELECT COUNT(*) FROM mstb_store_process_picking_list b WHERE b.msppl_stageId = NEW.msppl_stageId AND b.msppl_type = NEW.msppl_type ); 
    SET NEW.msppl_num = CONCAT(NEW.msppl_num,LPAD(max_count+1, 3, 0)); 

  ELSE

    SET max_count :=(SELECT COUNT(*) FROM mstb_store_process_picking_list b WHERE b.msppl_stageId = NEW.msppl_stageId AND b.msppl_type = NEW.msppl_type AND b.msppl_fields1 = NEW.msppl_fields1); 
    SET NEW.msppl_num = CONCAT(NEW.msppl_num,LPAD(max_count+1, 3, 0)); 

  END
  IF; 

END;
