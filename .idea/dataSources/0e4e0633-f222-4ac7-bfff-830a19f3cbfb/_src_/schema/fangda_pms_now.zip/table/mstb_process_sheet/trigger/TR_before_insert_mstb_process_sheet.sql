CREATE TRIGGER TR_before_insert_mstb_process_sheet
BEFORE INSERT ON mstb_process_sheet
FOR EACH ROW
  BEGIN
  DECLARE max_count int; 
  SET max_count :=(SELECT COUNT(*) FROM mstb_process_sheet b WHERE b.stage_id = NEW.stage_id); 
  SET NEW.mps_no = CONCAT(NEW.mps_no,LPAD(max_count+1, 3, 0)); 
END;
