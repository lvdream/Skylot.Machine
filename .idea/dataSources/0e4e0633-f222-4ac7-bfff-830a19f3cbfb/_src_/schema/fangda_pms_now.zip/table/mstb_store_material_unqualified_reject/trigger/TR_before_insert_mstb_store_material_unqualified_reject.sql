CREATE TRIGGER TR_before_insert_mstb_store_material_unqualified_reject
BEFORE INSERT ON mstb_store_material_unqualified_reject
FOR EACH ROW
  BEGIN
  DECLARE max_count int; 
  SET max_count := (SELECT COUNT(*) FROM mstb_store_material_unqualified_reject WHERE pro_id = NEW.pro_id AND smur_code like CONCAT(NEW.smur_code,'%')); 
  SET NEW.smur_code = CONCAT(NEW.smur_code,LPAD(max_count+1, 3, 0)); 
END;
