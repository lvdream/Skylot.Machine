CREATE TRIGGER TR_before_insert_mstb_store_material_supplement
BEFORE INSERT ON mstb_store_material_supplement
FOR EACH ROW
  BEGIN
  DECLARE max_count int; 
  SET max_count := (SELECT COUNT(*) FROM mstb_store_material_supplement WHERE pro_id = NEW.pro_id AND sms_code like CONCAT(NEW.sms_code,'%')); 
  SET NEW.sms_code = CONCAT(NEW.sms_code,LPAD(max_count+1, 3, 0)); 
END;
