CREATE TRIGGER TR_after_insert_data_on_xialiao_log
AFTER INSERT ON oftb_xiaoliao_action_log
FOR EACH ROW
  BEGIN

  DECLARE if_exist INT; 
  DECLARE count_from_stage INT; -- define the var which counted the number in stage
  DECLARE count_from_XL INT; -- define the var which counted the number in xl
  DECLARE count_from_PSA INT; -- define the var which counted the number in xl

  IF (new.xlal_type = 0)
  THEN
    INSERT INTO `mstb_xialiao_main` (`xlm_num`,
                                     `xlm_psaId`,
                                     `xlm_count`,
                                     `xlm_proId`,
                                     `xlm_stageId`,
                                     `xlm_psaType`,
                                     `xlm_prvId`,
                                     `xlm_splitType`,
                                     `xlm_create_type`,
                                     `xlm_type`,
                                     `xlm_status`,
                                     `xlm_createtime`,
                                     `xlm_createuser`, xlm_createusername, xlm_remark)
    VALUES (new.xlal_num,
      new.xlal_psaId,
      new.xlal_updated_count,
      new.xlal_proId,
      new.xlal_stageId,
      new.xlal_psaType,
      NULL,
      NULL,
      '0',
      '0',
      0,
            new.xlal_createtime,
            (SELECT FN_SPLIT_STR(new.xlal_createuser, '|||', 1)),
            (SELECT FN_SPLIT_STR(new.xlal_createuser, '|||', 2)),
            (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 16))
    ); 


    SET if_exist :=
    (SELECT count(*)
     FROM tstb_xialiao_amount_zj
     WHERE xaz_psa_id = new.xlal_psaId AND xaz_stage_id = new.xlal_stageId); 

    IF if_exist = 0
    THEN
      INSERT INTO `tstb_xialiao_amount_zj` (`xaz_psa_id`,
                                            `xaz_pro_id`,
                                            `xaz_stage_id`,
                                            `xaz_psa_type`,
                                            `xaz_psa_xl_amount`,
                                            `xaz_psa_name`,
                                            `xaz_psa_code`,
                                            `xaz_status`,
                                            `xaz_createtime`,
                                            `xaz_createuser`)
      VALUES (new.xlal_psaId,
              new.xlal_proId,
              new.xlal_stageId,
              new.xlal_psaType,
              new.xlal_updated_count,
              (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 14)),
              (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 15)),
              0,
              new.xlal_createtime,
              new.xlal_createuser); 
    ELSE
      -- hanld the multip process action, update by saul 20160819
      SET count_from_stage :=
      (SELECT sum(psps_count) AS t_count
       FROM oftb_project_stage_plate_summary
       WHERE stage_id = new.xlal_stageId AND psps_type = new.xlal_psaType AND
             psps_code = (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 15))
       GROUP BY stage_id, psps_type, psps_code); 
      SET count_from_XL :=
      (SELECT (xaz_psa_xl_amount + new.xlal_updated_count) AS t_count
       FROM tstb_xialiao_amount_zj
       WHERE xaz_psa_id = new.xlal_psaId AND xaz_stage_id = new.xlal_stageId); 
      IF (count_from_XL > count_from_stage)
      THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Over the Stage Total amount!'; 
      ELSE
        UPDATE `tstb_xialiao_amount_zj`
        SET xaz_psa_xl_amount = xaz_psa_xl_amount + new.xlal_updated_count, xaz_updatetime = new.xlal_createtime,
          xaz_updateuser      = new.xlal_createuser, xaz_status = 0
        WHERE xaz_psa_id = new.xlal_psaId AND xaz_stage_id = new.xlal_stageId; 
      END IF; 
    END IF; 
  ELSEIF (new.xlal_type = 1)
    THEN
      SET count_from_stage :=
      (SELECT `psam_quantity`
       FROM `mstb_project_stage_addtional_material`
       WHERE `psam_id` = new.xlal_psamId); 
      SET count_from_XL :=
      (SELECT count(*) AS t_count
       FROM tstb_xialiao_amount_cl
       WHERE xac_psam_id = new.xlal_psamId); 
      IF (count_from_XL > 0)
      THEN
        SET count_from_PSA :=
        (SELECT xac_psam_xl_amount
         FROM tstb_xialiao_amount_cl
         WHERE xac_psam_id = new.xlal_psamId); 
      ELSE
        SET count_from_PSA := 0; 

      END IF; 

      IF (count_from_stage < (count_from_PSA + new.xlal_updated_count))
      THEN

        DELETE FROM mstb_xialiao_main
        WHERE xlm_id = new.xlal_xlm_id; 
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Over the Stage Total amount!'; 

      ELSE
        INSERT INTO `mstb_xialiao_sub` (`xlm_id`,
                                        `xls_psam_id`,
                                        `xls_psam_xl_count`,
                                        xls_psam_split_type,
                                        `xls_psam_code`,
                                        `xls_psam_name`,
                                        `xls_psam_design_count`,
                                        `xls_psam_prvid`,
                                        `xls_psam_gc_code`,
                                        `xls_psam_gc_detail`,
                                        `xls_psam_bm_detail`,
                                        `xls_psam_purchase_size`,
                                        `xls_psam_lw_detail`,
                                        `xls_psam_weight`,
                                        `xls_psam_proceessed_size`,
                                        `xls_psas_processed_diagram`)
        VALUES (new.xlal_xlm_id,
          new.xlal_psamId,
          new.xlal_updated_count,
          (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 13)),
          (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 1)),
          (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 2)),
          (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 3)),
          (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 4)),
          (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 5)),
          (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 6)),
          (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 7)),
                (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 8)),
                (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 9)),
                (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 10)),
                (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 11)),
                (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 12))); 


        SET if_exist :=
        (SELECT count(*)
         FROM tstb_xialiao_amount_cl
         WHERE xac_psam_id = new.xlal_psamId AND xac_stage_id = new.xlal_stageId); 
        IF if_exist = 0
        THEN


          INSERT INTO tstb_xialiao_amount_cl (xac_psa_id, xac_pro_id, xac_stage_id, xac_psam_id,
                                              xac_psam_xl_amount, xac_psam_name, xac_psam_code, xac_psam_prv_id, xac_psam_mpm_id, xac_psam_mpm_detail, xac_psam_design_amount, xac_psam_design_size, xac_psam_process_size, xac_psam_bm_detail, xac_psam_process_diagram, xac_psam_lw_detail, xac_split_type, xaz_status, xaz_createtime, xaz_createuser, xac_psa_name, xac_psa_code, xac_psa_type)
          VALUES (new.xlal_psaId, new.xlal_proId, new.xlal_stageId, new.xlal_psamId, new.xlal_updated_count,
                                  (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 2)),
                                  (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 1)),
                                  (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 4)),
                                  (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 5)),
                                  (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 6)),
                                  (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 3)),
            (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 8)),
            (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 11)),
            (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 7)),
            (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 12)),
            (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 9)),
            (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 13)),
            0, new.xlal_createtime,
            new.xlal_createuser, (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 14)),
                  (SELECT FN_SPLIT_STR(new.xlal_materials_str, '|||', 15)),
                  new.xlal_psaType); 
        ELSE
          UPDATE tstb_xialiao_amount_cl
          SET xac_psam_xl_amount = xac_psam_xl_amount + new.xlal_updated_count, xaz_updatetime = new.xlal_createtime,
            xaz_updateuser       = new.xlal_createuser, xaz_status = 0
          WHERE xac_psam_id = new.xlal_psamId; 
        END IF; 
      END IF; 
  END IF; 
END;
