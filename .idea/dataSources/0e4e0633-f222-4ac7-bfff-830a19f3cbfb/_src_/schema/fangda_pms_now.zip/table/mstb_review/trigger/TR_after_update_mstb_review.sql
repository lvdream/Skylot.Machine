CREATE TRIGGER TR_after_update_mstb_review
AFTER UPDATE ON mstb_review
FOR EACH ROW
  BEGIN
  DECLARE hist_id_int INT ; 
  SET hist_id_int = (SELECT hist_id FROM mstb_review_history WHERE rev_id = NEW.rev_id ORDER BY hist_id desc LIMIT 0,1); 

  CALL SP_OF_TR_after_update_review(
      hist_id_int,
      NEW.pro_id,
      NEW.stage_id,
      NEW.rev_status,
      NEW.rev_type
  ); 
END;
