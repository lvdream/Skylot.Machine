CREATE TRIGGER TR_before_insert_mstb_review
BEFORE INSERT ON mstb_review
FOR EACH ROW
  BEGIN
  DECLARE max_count int; 
  -- 订购/加工 审核单
  IF (NEW.rev_type = '1' || NEW.rev_type = '2') THEN
    SET max_count := (SELECT COUNT(*) FROM mstb_review b WHERE b.pro_id = NEW.pro_id AND b.rev_no like CONCAT(NEW.rev_no,'%')); 
    SET NEW.rev_no = CONCAT(NEW.rev_no,max_count + 1); 
  END IF; 
END;
