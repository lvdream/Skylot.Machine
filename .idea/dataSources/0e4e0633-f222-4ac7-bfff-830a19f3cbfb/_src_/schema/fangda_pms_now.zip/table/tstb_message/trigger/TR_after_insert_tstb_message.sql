CREATE TRIGGER TR_after_insert_tstb_message
AFTER INSERT ON tstb_message
FOR EACH ROW
  BEGIN

  SET @mes_id = NEW.mes_id; 
  SET @mes_businessid = NEW.mes_businessid; 
  SET @mes_receivetype = NEW.mes_receivetype; 
  SET @mes_option2 = NEW.mes_option2; 

END;
