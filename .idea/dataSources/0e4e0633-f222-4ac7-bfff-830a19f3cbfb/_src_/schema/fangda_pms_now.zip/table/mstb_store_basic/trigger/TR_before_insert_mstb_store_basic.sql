CREATE TRIGGER TR_before_insert_mstb_store_basic
BEFORE INSERT ON mstb_store_basic
FOR EACH ROW
  BEGIN
  DECLARE max_count int; 
  if(new.msb_type='1')THEN
    SET max_count :=(SELECT COUNT(*) FROM mstb_store_basic b WHERE b.msb_type='1'); 
    SET new.msb_id =CONCAT('',LPAD(max_count+1, 3, 0)); 
  ELSE SET max_count :=(SELECT COUNT(*) FROM mstb_store_basic b WHERE b.parent_id= new.parent_id ); 
    SET new.msb_id =CONCAT(CONCAT(new.parent_id,'_'),LPAD(max_count+1, 3, 0)); 
  END IF; 
END;
