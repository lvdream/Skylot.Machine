CREATE TRIGGER TR_after_insert_mstb_store_material_instore_detail
AFTER INSERT ON mstb_store_material_instore_detail
FOR EACH ROW
  BEGIN

DECLARE msmu_id_int INT;
DECLARE order_number_int INT;
DECLARE o_instore_num_int INT;

-- -- 上架管理,目前已经弃用这个功能 update by Saul 20170110

SET msmu_id_int = (
        SELECT msmu_id FROM mstb_store_material_unonshelves
        WHERE pro_id = NEW.pro_id AND msmu_type = NEW.smid_type AND psam_code = NEW.psam_code LIMIT 0,1
);

IF (ISNULL(msmu_id_int)) THEN
        INSERT INTO mstb_store_material_unonshelves (
                pro_id,
                pv_id,
                psam_id,
                psam_code,
                msmu_num,
                msmu_type,
                msmu_mpm_id,
                msmu_length,
                msmu_weight_single,
                msmu_action_area,
                msmu_backup2,
                msmu_createdate
        )
        VALUES(
                NEW.pro_id,
                NEW.pv_id,
                NEW.psam_id,
                NEW.psam_code,
                NEW.smid_num,
                NEW.smid_type,
                NEW.smid_mpm_id,
                NEW.smid_length,
                NEW.smid_weight_single,
                NEW.smid_action_area,
                NEW.smid_vendor_symbol,
                NEW.smid_backup2
        );
ELSE
        UPDATE mstb_store_material_unonshelves SET msmu_num = msmu_num + NEW.smid_num WHERE msmu_id = msmu_id_int;
END IF;
-- -- 上架管理结束

-- 订单明细更新逻辑开始 
SELECT mpom_purchaseNumber,mpom_hasReceiving_count INTO order_number_int,o_instore_num_int FROM mstb_purchase_order_material WHERE mpom_id = NEW.mpom_id;
IF (order_number_int - o_instore_num_int - NEW.smid_num > 0) THEN -- 如果订单材料明细中,下单数量减去已收货数量,再减去本次收货数量,如果还是大于零,说明当前对象还是收货中
        UPDATE mstb_purchase_order_material SET mpom_status = '4',mpom_hasReceiving_count = o_instore_num_int + NEW.smid_num WHERE mpom_id = NEW.mpom_id;
ELSE
        UPDATE mstb_purchase_order_material SET mpom_status = '2',mpom_hasReceiving_count = o_instore_num_int + NEW.smid_num WHERE mpom_id = NEW.mpom_id;
END IF;
-- 订单明细更新逻辑结束
END;
