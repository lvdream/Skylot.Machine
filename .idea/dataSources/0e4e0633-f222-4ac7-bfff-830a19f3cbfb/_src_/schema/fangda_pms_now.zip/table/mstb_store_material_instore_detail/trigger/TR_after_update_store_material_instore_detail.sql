CREATE TRIGGER TR_after_update_store_material_instore_detail
AFTER UPDATE ON mstb_store_material_instore_detail
FOR EACH ROW
  BEGIN

  DECLARE can_count_int INT; 
  DECLARE order_number_int INT; 
  DECLARE o_instore_num_int INT ; 

  IF(NEW.smid_num != OLD.smid_num)THEN -- 如果收货明细库存进行了增加或者减少
    SET can_count_int = NEW.smid_num - OLD.smid_num; 
    SELECT mpom_purchaseNumber,mpom_hasReceiving_count INTO order_number_int,o_instore_num_int FROM mstb_purchase_order_material WHERE mpom_id = NEW.mpom_id; 
    IF((o_instore_num_int + can_count_int)=0) then -- 收货弃用,收货详情数量和已收货数量一样,说明材料的收货状态要改为未收货
      UPDATE mstb_purchase_order_material SET mpom_status = '1',mpom_hasReceiving_count = mpom_hasReceiving_count + can_count_int WHERE mpom_id = NEW.mpom_id; 
    else
      IF(order_number_int - (o_instore_num_int + can_count_int) > 0) THEN
        UPDATE mstb_purchase_order_material SET mpom_status = '4',mpom_hasReceiving_count = mpom_hasReceiving_count + can_count_int WHERE mpom_id = NEW.mpom_id; 
      else
        IF(order_number_int - (o_instore_num_int + can_count_int) = 0) THEN
          UPDATE mstb_purchase_order_material SET mpom_status = '4',mpom_hasReceiving_count = mpom_hasReceiving_count + can_count_int WHERE mpom_id = NEW.mpom_id; 
        END IF; 
      END IF; 
    end IF; 
  END IF; 
END;
