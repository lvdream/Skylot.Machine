CREATE TRIGGER TR_before_insert_mstb_buildsite_material_supplement
BEFORE INSERT ON mstb_buildsite_material_supplement
FOR EACH ROW
  BEGIN
  DECLARE max_count int; 
  SET max_count := (SELECT COUNT(*) FROM mstb_buildsite_material_supplement WHERE pro_id = NEW.pro_id AND bms_code like CONCAT(NEW.bms_code,'%')); 
  SET NEW.bms_code = CONCAT(NEW.bms_code,LPAD(max_count+1, 3, 0)); 
END;
