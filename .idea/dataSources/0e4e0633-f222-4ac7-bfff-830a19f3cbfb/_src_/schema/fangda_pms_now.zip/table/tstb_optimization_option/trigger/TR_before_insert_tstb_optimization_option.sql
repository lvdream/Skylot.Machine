CREATE TRIGGER TR_before_insert_tstb_optimization_option
BEFORE INSERT ON tstb_optimization_option
FOR EACH ROW
  BEGIN
  DECLARE max_count INT; 

  SET max_count := (
    SELECT COUNT(*) FROM tstb_optimization_option b WHERE b.pv_id = new.pv_id AND b.too_fields10 = new.too_fields10
  ); 

  IF (new.pv_id != '1') THEN

    SET new.too_fields5 = CONCAT(new.too_fields5,LPAD(max_count + 1, 3, 0)); 

  ELSE

    SET new.too_fields5 = new.too_fields5; 

  END
  IF; 

END;
