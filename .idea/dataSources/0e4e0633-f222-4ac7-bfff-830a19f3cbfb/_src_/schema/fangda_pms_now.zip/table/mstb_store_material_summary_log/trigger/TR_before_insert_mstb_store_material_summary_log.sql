CREATE TRIGGER TR_before_insert_mstb_store_material_summary_log
BEFORE INSERT ON mstb_store_material_summary_log
FOR EACH ROW
  BEGIN

DECLARE y_msfm_total_count INT;

SET y_msfm_total_count := (
        SELECT
                IFNULL(sum(sum_total_num),0)
        FROM
                mstb_store_material_summary a
        WHERE
                a.pro_id = new.pro_id
        AND a.psam_code = new.psam_code         
        AND a.sum_type = new.log_material_type
        AND a.pv_id = new.pv_id
);
IF(new.log_type='4' OR new.log_type='9'OR new.log_type='10' )THEN
SET new.log_current_count=y_msfm_total_count-new.log_num;

ELSEIF(new.log_type='1' OR new.log_type='6' OR new.log_type='7' OR new.log_type='11')THEN

SET new.log_current_count=y_msfm_total_count+new.log_num;
ELSE 
        SET new.log_current_count=new.log_num;
end IF;
end;
