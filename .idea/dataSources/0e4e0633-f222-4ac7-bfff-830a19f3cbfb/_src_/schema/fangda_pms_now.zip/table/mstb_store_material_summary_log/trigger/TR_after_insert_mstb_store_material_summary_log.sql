CREATE TRIGGER TR_after_insert_mstb_store_material_summary_log
AFTER INSERT ON mstb_store_material_summary_log
FOR EACH ROW
  BEGIN

  DECLARE sum_id_int INT; 
  DECLARE msmo_id_int INT; 
  DECLARE dif_count_int INT ; 
  DECLARE leftNum INT ; 


  IF (NEW.log_type = '1') THEN
    SET sum_id_int = (
      SELECT sum_id FROM mstb_store_material_summary WHERE pro_id = NEW.pro_id AND pv_id = NEW.pv_id AND psam_code = NEW.psam_code AND sum_type = NEW.log_material_type LIMIT 1
    ); 
    IF (ISNULL(sum_id_int)) THEN
      INSERT INTO mstb_store_material_summary (
        pro_id,
        pv_id,
        psam_code,
        sum_total_num,
        sum_yuding_num,
        sum_type,
        sum_updatedate,
        sum_updateuser,
        sum_length,
        sum_weight_single,
        sum_action_area,
        sum_vendor_symbol,
        sum_mpm_id,
        sum_backup2,
        sum_psam_name,
        sum_process_draw_number
      )
      VALUES(
        NEW.pro_id,
        NEW.pv_id,
        NEW.psam_code,
        NEW.log_num,
        0,
        NEW.log_material_type,
        NEW.log_createdate,
        NEW.log_createuser,
        NEW.log_length,
        NEW.log_weight_single,
        NEW.log_action_area,
        NEW.log_vendor_symbol,
        NEW.log_mpm_id,
        NEW.log_backup4,
        NEW.log_psam_name,
        NEW.log_process_draw_number
      ); 
    ELSE
      UPDATE mstb_store_material_summary SET sum_total_num = (sum_total_num + NEW.log_num) WHERE sum_id = sum_id_int; 
    END IF; 
  ELSEIF (NEW.log_type = '2') THEN
    SET leftNum:=(SELECT sum_total_num-sum_yuding_num FROM mstb_store_material_summary  WHERE sum_id = NEW.sms_id); 
    IF (NEW.sms_id = '' OR NEW.sms_id = NULL) THEN
      UPDATE mstb_store_material_summary SET sum_yuding_num = (sum_yuding_num + NEW.log_num) WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND sum_type = NEW.log_material_type; 
    ELSEIF(leftNum >=NEW.log_num)       then
      UPDATE mstb_store_material_summary SET sum_yuding_num = (sum_yuding_num + NEW.log_num) WHERE sum_id = NEW.sms_id; 
    ELSE
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'the log_num over ky_num'; 
    END IF; 
  ELSEIF (NEW.log_type = '3') THEN
    SET msmo_id_int = (
      SELECT msmo_id FROM mstb_store_material_onshelves WHERE pro_id = NEW.pro_id AND msmo_type = NEW.log_material_type AND psam_code = NEW.psam_code AND msb_id = NEW.msb_id LIMIT 1
    ); 
    IF (ISNULL(msmo_id_int)) THEN
      INSERT INTO mstb_store_material_onshelves (
        pro_id,
        pv_id,
        msb_id,
        psam_code,
        msmo_type,
        msmo_num,
        msmo_mpm_id,
        msmo_length,
        msmo_weight_single,
        msmo_action_area,
        msmo_backup2,
        msmo_createdate
      )
      VALUES(
        NEW.pro_id,
        NEW.pv_id,
        NEW.msb_id,
        NEW.psam_code,
        NEW.log_material_type,
        NEW.log_num,
        NEW.log_mpm_id,
        NEW.log_length,
        NEW.log_weight_single,
        NEW.log_action_area,
        NEW.log_vendor_symbol,
        NEW.log_backup4
      ); 
    ELSE
      UPDATE mstb_store_material_onshelves SET msmo_num = (msmo_num + NEW.log_num) WHERE msmo_id = msmo_id_int; 
    END IF; 
    UPDATE mstb_store_material_unonshelves SET msmu_num = (msmu_num - NEW.log_num) WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND msmu_type = NEW.log_material_type; 
  ELSEIF (NEW.log_type = '4' OR NEW.log_type = '10' ) THEN
    UPDATE mstb_store_material_summary SET sum_total_num = (sum_total_num - NEW.log_num),sum_yuding_num = (sum_yuding_num - NEW.log_num) WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND sum_type = NEW.log_material_type; 
  ELSEIF (NEW.log_type = '5') THEN
    UPDATE mstb_store_material_summary SET sum_yuding_num = (sum_yuding_num - NEW.log_num) WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND sum_type = NEW.log_material_type; 
  ELSEIF (NEW.log_type = '6' OR NEW.log_type = '11') THEN
    UPDATE mstb_store_material_summary SET sum_total_num = (sum_total_num + NEW.log_num) WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND sum_type = NEW.log_material_type; 
  ELSEIF (NEW.log_type = '7') THEN
    UPDATE mstb_store_material_summary SET sum_total_num = (sum_total_num + NEW.log_num) WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND sum_type = NEW.log_material_type; 
    UPDATE mstb_store_material_unonshelves SET msmu_num = msmu_num + (NEW.log_num) WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND sum_type = NEW.log_material_type; 
  ELSEIF (NEW.log_type = '9' ) THEN
    UPDATE mstb_store_material_summary SET sum_total_num = (sum_total_num - NEW.log_num) WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND sum_type = NEW.log_material_type; 

  END IF; 


END;
