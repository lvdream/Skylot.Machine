CREATE TRIGGER TR_before_insert_tstb_optimization_log
BEFORE INSERT ON tstb_optimization_log
FOR EACH ROW
  BEGIN
  DECLARE max_count INT; 

  SET max_count := ( SELECT COUNT(*) FROM tstb_optimization_log b WHERE b.pv_id = new.pv_id AND b.stage_id = new.stage_id ); 

  SET new.tol_lognumbers = CONCAT( new.tol_lognumbers, LPAD(max_count + 1, 4, 0) ); 

END;
