CREATE TRIGGER TR_after_insert_mspsl
AFTER INSERT ON mstb_store_product_summary_log
FOR EACH ROW
  BEGIN

  IF (NEW.spsl_operation = 0) THEN

    IF NOT EXISTS(SELECT 1 FROM mstb_store_product_summary spms
    WHERE spms.pro_id = NEW.pro_id AND spms.pst_id = NEW.pst_id AND spms.psa_id = NEW.psa_id) THEN
      INSERT INTO mstb_store_product_summary(
        pro_id,
        pst_id,
        psa_id,
        psa_code,
        psa_name,
        psa_type,
        sps_hadinstore_num,
        sps_updateuser,
        sps_updatedate
      ) VALUES (
        NEW.pro_id,
        NEW.pst_id,
        NEW.psa_id,
        NEW.psa_code,
        NEW.psa_name,
        NEW.psa_type,
        NEW.spsl_storenum,
        NEW.spsl_createuser,
        NEW.spsl_createdate
      ); 
    ELSE
      UPDATE mstb_store_product_summary
      SET sps_hadinstore_num = sps_hadinstore_num + (NEW.spsl_storenum),
        sps_updatedate = NEW.spsl_createdate,
        sps_updateuser = NEW.spsl_createuser
      WHERE pro_id = NEW.pro_id AND pst_id = NEW.pst_id AND psa_id = NEW.psa_id; 
    END IF; 

  ELSEIF(NEW.spsl_operation = 1) THEN
    UPDATE mstb_store_product_summary
    SET sps_hadoutstore_num = sps_hadoutstore_num + (NEW.spsl_storenum),
      sps_updatedate = NEW.spsl_createdate,
      sps_updateuser = NEW.spsl_createuser
    WHERE pro_id = NEW.pro_id AND pst_id = NEW.pst_id AND psa_id = NEW.psa_id; 

  ELSEIF(NEW.spsl_operation = 2) THEN
    UPDATE mstb_store_product_summary
    SET sps_bookoutstore_num = sps_bookoutstore_num + (NEW.spsl_storenum),
      sps_updatedate = NEW.spsl_createdate,
      sps_updateuser = NEW.spsl_createuser
    WHERE pro_id = NEW.pro_id AND pst_id = NEW.pst_id AND psa_id = NEW.psa_id; 
  END IF; 
END;
