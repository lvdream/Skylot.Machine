CREATE TRIGGER TR_after_insert_data_on_store_freezed_materials_log
AFTER INSERT ON tstb_store_freezed_material_log
FOR EACH ROW
  BEGIN
        DECLARE
                if_exist INT;

DECLARE
        y_msfm_total_count INT;

DECLARE
        y_count INT;

SET if_exist := (
        SELECT
                count(*)
        FROM
                mstb_store_freezed_material_main
        WHERE
        msfm_pro_id = new.tsfml_pro_id  AND msfm_is_yh = new.tsfml_is_yh
        AND msfm_prv_id = new.tsfml_prv_id
        AND msfm_psam_code = new.tsfml_psam_code
);

IF (
        new.tsfml_updated_type = '4'
        OR new.tsfml_updated_type = '5'
) THEN

IF if_exist = 0 THEN
        INSERT INTO mstb_store_freezed_material_main (
                msfm_psam_id,
                msfm_pro_id,
                                msfm_prv_id,
                msfm_psam_code,
                msfm_total_count,
                msfm_reserve_count,
                msfm_variable_count,
                msfm_createusercode,
                msfm_createusername,
                msfm_createdate,
                psam_option6,
                psam_design_size,
                mpm_id,
                psam_weight_single,
                psam_action_area,
                msfm_is_yh
        )
VALUES
        (
                new.tsfml_psam_id,
                new.tsfml_pro_id,
                                new.tsfml_prv_id,
                new.tsfml_psam_code,
                new.tsfml_updated_count,
                0,
                0,
                new.tsfml_createuser_code,
                new.tsfml_createuser_name,
                new.tsfml_createdate,
                (
                        SELECT
                                FN_SPLIT_STR (new.tsfml_option1, '|||', 1)
                ),
                (
                        SELECT
                                FN_SPLIT_STR (new.tsfml_option1, '|||', 2)
                ),
                (
                        SELECT
                                FN_SPLIT_STR (new.tsfml_option1, '|||', 3)
                ),
                (
                        SELECT
                                FN_SPLIT_STR (new.tsfml_option1, '|||', 4)
                ),
                (
                        SELECT
                                FN_SPLIT_STR (new.tsfml_option1, '|||', 5)
                ),
                new.tsfml_is_yh
        );

ELSEIF (
        new.tsfml_updated_business = '2'
) THEN

SET y_count = (
        SELECT
                count(1)
        FROM
                mstb_store_freezed_material_main
        WHERE
         msfm_pro_id = new.tsfml_pro_id
        AND msfm_is_yh = new.tsfml_is_yh
        AND msfm_prv_id = new.tsfml_prv_id
        AND msfm_psam_code = new.tsfml_psam_code
        AND msfm_total_count = new.tsfml_y_count
);


IF (y_count > 0) THEN
        UPDATE mstb_store_freezed_material_main
SET msfm_total_count = msfm_total_count + new.tsfml_updated_count,
 msfm_createusercode = new.tsfml_createuser_code,
 msfm_createusername = new.tsfml_createuser_name,
 msfm_createdate = new.tsfml_createdate
WHERE
 msfm_is_yh = new.tsfml_is_yh
AND msfm_pro_id = new.tsfml_pro_id
AND msfm_prv_id = new.tsfml_prv_id
AND msfm_psam_code = new.tsfml_psam_code;


ELSE
        SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'the count is changed';


END IF;


ELSE

SET y_msfm_total_count := (
        SELECT
                msfm_total_count
        FROM
                mstb_store_freezed_material_main
        WHERE
         msfm_pro_id = new.tsfml_pro_id
        AND msfm_is_yh = new.tsfml_is_yh
        AND msfm_prv_id = new.tsfml_prv_id
        AND msfm_psam_code = new.tsfml_psam_code
);


IF (
        y_msfm_total_count + new.tsfml_updated_count >= 0
) THEN
        UPDATE mstb_store_freezed_material_main
SET msfm_total_count = y_msfm_total_count + new.tsfml_updated_count,
 msfm_createusercode = new.tsfml_createuser_code,
 msfm_createusername = new.tsfml_createuser_name,
 msfm_createdate = new.tsfml_createdate
WHERE
        msfm_pro_id = new.tsfml_pro_id
AND msfm_is_yh = new.tsfml_is_yh
AND msfm_prv_id = new.tsfml_prv_id
AND msfm_psam_code = new.tsfml_psam_code;


ELSE
        SIGNAL SQLSTATE '45000'
SET MESSAGE_TEXT = 'the new count over total count';


END IF;


END IF;

ELSEIF (
        new.tsfml_updated_type = '1'
        OR new.tsfml_updated_type = '0'
) THEN
        UPDATE mstb_store_freezed_material_main
SET msfm_variable_count = msfm_variable_count + new.tsfml_updated_count,
 msfm_createusercode = new.tsfml_createuser_code,
 msfm_createusername = new.tsfml_createuser_name,
 msfm_createdate = new.tsfml_createdate
WHERE
         msfm_pro_id = new.tsfml_pro_id
AND msfm_is_yh = new.tsfml_is_yh
AND msfm_prv_id = new.tsfml_prv_id
AND msfm_psam_code = new.tsfml_psam_code;

ELSEIF (
        new.tsfml_updated_type = '2'
        OR new.tsfml_updated_type = '3'
) THEN
        UPDATE mstb_store_freezed_material_main
SET msfm_reserve_count = msfm_reserve_count + new.tsfml_updated_count,
 msfm_createusercode = new.tsfml_createuser_code,
 msfm_createusername = new.tsfml_createuser_name,
 msfm_createdate = new.tsfml_createdate
WHERE
        msfm_pro_id = new.tsfml_pro_id
AND msfm_is_yh = new.tsfml_is_yh
AND msfm_prv_id = new.tsfml_prv_id
AND msfm_psam_code = new.tsfml_psam_code;


END IF;


END;
