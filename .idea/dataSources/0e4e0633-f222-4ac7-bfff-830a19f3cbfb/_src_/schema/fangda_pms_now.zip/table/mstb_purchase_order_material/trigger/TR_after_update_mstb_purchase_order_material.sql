CREATE TRIGGER TR_after_update_mstb_purchase_order_material
AFTER UPDATE ON mstb_purchase_order_material
FOR EACH ROW
  BEGIN

DECLARE total_count_int INT;
DECLARE count_instoring_int INT; 
DECLARE count_instored_int INT;
IF(old.mpom_status!=new.mpom_status AND (new.mpom_status='1' OR new.mpom_status='2' OR new.mpom_status='4'))THEN
-- 1 未收货, 2 已收货, 4 收货中
                SET count_instored_int = (SELECT COUNT(1) FROM mstb_purchase_order_material WHERE mpom_o_id=new.mpom_o_id AND mpom_status='2'); -- 已收货的订单明细数量
                SET total_count_int = (SELECT COUNT(1) FROM mstb_purchase_order_material WHERE mpom_o_id=new.mpom_o_id ); -- 当前订单明细数量
                IF(count_instored_int = 0) THEN -- 如果没有已收货的数量
                        UPDATE mstb_purchase_order_main SET o_status=new.mpom_status WHERE o_id=new.mpom_o_id; -- 按照当前材料明细的状态更新主对象的状态
                ELSEIF (count_instored_int = total_count_int) THEN -- 订单明细的总数和已收货的总数相等,那么订单状态改为已收货
                        UPDATE mstb_purchase_order_main SET o_status='2' WHERE o_id=new.mpom_o_id; 
                END IF; 
        END IF;
END;
