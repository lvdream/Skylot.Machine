CREATE TRIGGER TR_before_insert_mspms
BEFORE INSERT ON mstb_store_product_material_summary
FOR EACH ROW
  BEGIN
  SET NEW.spms_currentstore_num =
  NEW.spms_hadinstore_num - (NEW.spms_hadoutstore_num + NEW.spms_bookoutstore_num); 
END;
