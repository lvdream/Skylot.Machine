CREATE TRIGGER TR_before_insert_mstb_store_product_outstore
BEFORE INSERT ON mstb_store_product_outstore
FOR EACH ROW
  BEGIN
  DECLARE max_count int; 
  SET max_count := (SELECT COUNT(*) FROM mstb_store_product_outstore WHERE pro_id = NEW.pro_id AND spo_storeorder like CONCAT(NEW.spo_storeorder,'%')); 
  SET NEW.spo_storeorder = CONCAT(NEW.spo_storeorder,LPAD(max_count+1, 3, 0)); 
END;
