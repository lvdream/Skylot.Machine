CREATE TRIGGER TR_after_update_mstb_stage_image
AFTER UPDATE ON mstb_stage_image
FOR EACH ROW
  BEGIN

  SET @stage_id = NEW.stage_id; 
  SET @image_id = NEW.image_id; 
  SET @image_type = NEW.image_type; 
  SET @OLD_image_status = OLD.image_status; 
  SET @NEW_image_status = NEW.image_status; 
  SET @image_updateuser = NEW.image_updateuser; 
  SET @image_updatedate = NEW.image_updatedate; 

  CALL SP_OF_TR_after_update_msi(
      @stage_id,
      @image_id,
      @image_type,
      @OLD_image_status,
      @NEW_image_status,
      @image_updateuser,
      @image_updatedate
  ); 
  IF(NEW.image_status = '2' )THEN
    CALL SP_OF_TR_after_update_image_for_split(
        @image_id
    ); 
  END IF; 
END;
