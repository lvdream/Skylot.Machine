CREATE TRIGGER TR_after_insert_mstb_store_material_site_summary_log
AFTER INSERT ON mstb_store_material_site_summary_log
FOR EACH ROW
  BEGIN

  DECLARE sum_id_int INT; 
  DECLARE msmo_id_int INT; 
  DECLARE dif_count_int INT; 

  IF (NEW.log_type = '1' OR NEW.log_type = '-1') THEN
    SET sum_id_int = (
      SELECT mss_id FROM mstb_store_material_site_summary WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND mss_type = NEW.log_material_type LIMIT 1
    ) ; 

    IF (ISNULL(sum_id_int)) THEN
      INSERT INTO mstb_store_material_site_summary (
        pro_id,
        pv_id,
        psam_code,
        mss_total_num,
        mss_type,
        mss_updatedate,
        mss_updateuser,
        psam_length,
        psam_weight_single,
        psam_action_area,
        vendor_symbol,
        mpm_id,
        backup4,
        mss_process_draw_number
      )
      VALUES
        (
          NEW.pro_id,
          NEW.pv_id,
          NEW.psam_code,
          NEW.log_num,
          NEW.log_material_type,
          NEW.log_createdate,
          NEW.log_createuser,
          NEW.psam_length,
          NEW.psam_weight_single,
          NEW.psam_action_area,
          NEW.vendor_symbol,
          NEW.mpm_id,
          NEW.backup2,
          New.log_process_draw_number
        ) ; 
    ELSE
      UPDATE mstb_store_material_site_summary SET mss_total_num = (mss_total_num + NEW.log_num) WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND mss_type = NEW.log_material_type ; 
    END IF ; 
  ELSEIF (NEW.log_type = '2') THEN -- this rule add by rick.wang at 2016/08/15
    UPDATE mstb_store_material_site_summary SET mss_total_num = (mss_total_num - NEW.log_num) WHERE pro_id = NEW.pro_id AND psam_code = NEW.psam_code AND mss_type = NEW.log_material_type ; 
  END IF; 

END;
