CREATE TRIGGER TR_before_insert_mstb_store_material_site_summary_log
BEFORE INSERT ON mstb_store_material_site_summary_log
FOR EACH ROW
  BEGIN

DECLARE y_msfm_total_count INT;

SET y_msfm_total_count := (
        SELECT
                IFNULL(sum(mss_total_num),0)
        FROM
                mstb_store_material_site_summary a
        WHERE
                a.pro_id = new.pro_id
        AND a.psam_code = new.psam_code         
        AND a.mss_type = new.log_material_type
        AND a.pv_id = new.pv_id
);
IF(new.log_type='2')THEN
SET new.log_current_count=y_msfm_total_count-new.log_num;

ELSEIF(new.log_type='1' OR NEW.log_type = '-1')THEN

SET new.log_current_count=y_msfm_total_count+new.log_num;
ELSE 
        SET new.log_current_count=new.log_num;
end IF;
end;
