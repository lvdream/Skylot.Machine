CREATE TRIGGER TR_before_insert_mstb_meterial_project_properties
BEFORE INSERT ON mstb_meterial_project_properties
FOR EACH ROW
  BEGIN

  DECLARE last_mpp_symbol_num VARCHAR(255); 
  IF(NEW.prov_id != 1 AND NEW.prov_id != 2 AND NEW.prov_id != 3
     AND NEW.prov_id != 4 AND NEW.prov_id != 5 AND NEW.prov_id != 6
     AND NEW.prov_id != 9) THEN
    SET last_mpp_symbol_num := (SELECT TRIM(LEADING '0' FROM SUBSTRING_INDEX(mpp_symbol,'_',-1))
                                FROM mstb_meterial_project_properties
                                WHERE proj_id=NEW.proj_id AND prov_id=NEW.prov_id
                                ORDER BY mpp_id DESC LIMIT 1); 
    IF FN_IsNum(last_mpp_symbol_num) = 0 THEN
      SET NEW.mpp_symbol := CONCAT(NEW.mpp_symbol,'001'); 
    ELSE
      SET NEW.mpp_symbol := CONCAT(NEW.mpp_symbol,LPAD(last_mpp_symbol_num + 1, 3, 0)); 
    END IF; 
  END IF; 
END;
