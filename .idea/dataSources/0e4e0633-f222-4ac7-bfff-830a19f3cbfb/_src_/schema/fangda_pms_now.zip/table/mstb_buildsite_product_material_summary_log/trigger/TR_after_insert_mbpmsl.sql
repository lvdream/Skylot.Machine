CREATE TRIGGER TR_after_insert_mbpmsl
AFTER INSERT ON mstb_buildsite_product_material_summary_log
FOR EACH ROW
  BEGIN

  IF (NEW.bpmsl_operation = 0) THEN

    IF NOT EXISTS(SELECT 1 FROM mstb_buildsite_product_material_summary bpms
    WHERE bpms.pro_id = NEW.pro_id AND bpms.pst_id = NEW.pst_id
          AND bpms.psa_id = NEW.psa_id AND bpms.psam_id = NEW.psam_id) THEN
      INSERT INTO mstb_buildsite_product_material_summary(
        pro_id,
        pst_id,
        psa_id,
        psa_code,
        psa_name,
        psa_type,
        psam_id,
        psam_code,
        psam_name,
        prv_id,
        bpms_hadinstore_num,
        bpms_updateuser,
        bpms_updatedate
      ) VALUES (
        NEW.pro_id,
        NEW.pst_id,
        NEW.psa_id,
        NEW.psa_code,
        NEW.psa_name,
        NEW.psa_type,
        NEW.psam_id,
        NEW.psam_code,
        NEW.psam_name,
        NEW.prv_id,
        NEW.bpmsl_storenum,
        NEW.bpmsl_createuser,
        NEW.bpmsl_createdate
      ); 
    ELSE
      UPDATE mstb_buildsite_product_material_summary
      SET bpms_hadinstore_num = bpms_hadinstore_num + (NEW.bpmsl_storenum),
        bpms_updatedate = NEW.bpmsl_createdate,
        bpms_updateuser = NEW.bpmsl_createuser
      WHERE pro_id = NEW.pro_id AND pst_id = NEW.pst_id
            AND psa_id = NEW.psa_id AND psam_id = NEW.psam_id; 
    END IF; 
  END IF; 
END;
