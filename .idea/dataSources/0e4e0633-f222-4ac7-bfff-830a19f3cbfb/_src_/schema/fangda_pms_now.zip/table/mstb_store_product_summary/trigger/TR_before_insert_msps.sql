CREATE TRIGGER TR_before_insert_msps
BEFORE INSERT ON mstb_store_product_summary
FOR EACH ROW
  BEGIN
  SET NEW.sps_currentstore_num =
  NEW.sps_hadinstore_num - (NEW.sps_hadoutstore_num + NEW.sps_bookoutstore_num); 
END;
