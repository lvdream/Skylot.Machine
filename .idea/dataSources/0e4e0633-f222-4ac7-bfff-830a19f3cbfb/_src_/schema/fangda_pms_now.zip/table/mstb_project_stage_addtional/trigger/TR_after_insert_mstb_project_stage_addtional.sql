CREATE TRIGGER TR_after_insert_mstb_project_stage_addtional
AFTER INSERT ON mstb_project_stage_addtional
FOR EACH ROW
  BEGIN
  DECLARE CONSTANT_PSA_TYPE_DYMJ varchar(1) DEFAULT '1'; 
  DECLARE CONSTANT_PSA_TYPE_DYZJ varchar(1) DEFAULT '2'; 
  DECLARE CONSTANT_PSA_TYPE_DYFJ varchar(1) DEFAULT '3'; 
  DECLARE CONSTANT_PSA_TYPE_KJMJ varchar(1) DEFAULT '4'; 
  DECLARE CONSTANT_PSA_TYPE_KJGJ varchar(1) DEFAULT '5'; 
  DECLARE CONSTANT_PSA_TYPE_KJMB varchar(1) DEFAULT '6'; 
  DECLARE CONSTANT_PSA_TYPE_KJFJ varchar(1) DEFAULT '7'; 
  DECLARE CONSTANT_PSA_TYPE_KJZST varchar(1) DEFAULT '8'; 


  IF(NEW.psa_type = CONSTANT_PSA_TYPE_DYMJ ||
     NEW.psa_type= CONSTANT_PSA_TYPE_KJMJ ||
     NEW.psa_type= CONSTANT_PSA_TYPE_KJGJ ) THEN
    INSERT INTO mstb_design_split_main(pro_id,stage_id,psa_id,psa_code,psa_type,dsm_status)
    VALUES(NEW.pro_id,NEW.pst_id,NEW.psa_id,NEW.psa_code,NEW.psa_type,'0'); 
  END IF; 
END;
