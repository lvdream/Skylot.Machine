CREATE TRIGGER TR_before_insert_mstb_project_stage_addtional
BEFORE INSERT ON mstb_project_stage_addtional
FOR EACH ROW
  BEGIN
  DECLARE max_count int; 
  -- 清单设计单的设计单号序号生成由系统自动和创建  >= 20是临时使用
  IF (NEW.psa_type >= 20) THEN
    SET max_count := (
      SELECT COUNT(*) FROM mstb_project_stage_addtional psa
      WHERE psa.pro_id = NEW.pro_id AND psa.pst_id = NEW.pst_id AND psa.psa_code LIKE CONCAT(NEW.psa_code,'%')
    ); 
    SET NEW.psa_code = CONCAT(NEW.psa_code,LPAD(max_count+1, 3, 0)); 
  END IF; 
END;
