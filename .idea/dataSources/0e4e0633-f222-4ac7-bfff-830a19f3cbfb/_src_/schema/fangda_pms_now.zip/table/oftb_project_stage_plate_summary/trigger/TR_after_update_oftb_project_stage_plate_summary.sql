CREATE TRIGGER TR_after_update_oftb_project_stage_plate_summary
AFTER UPDATE ON oftb_project_stage_plate_summary
FOR EACH ROW
  BEGIN

  SET @pro_id = NEW.pro_id; 
  SET @psps_type = NEW.psps_type; 
  SET @psps_code = NEW.psps_code; 
  SET @OLD_psps_count = OLD.psps_count; 
  SET @NEW_psps_count = NEW.psps_count; 

  CALL SP_OF_TR_after_update_opsps(
      @pro_id,
      @psps_type,
      @psps_code,
      @OLD_psps_count,
      @NEW_psps_count
  ); 

END;
