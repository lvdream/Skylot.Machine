CREATE TRIGGER TR_after_insert_mstb_design_split_main
AFTER INSERT ON mstb_design_split_main
FOR EACH ROW
  BEGIN
  DECLARE psam_id_int INT; 
  DECLARE done INT DEFAULT FALSE; 

  DECLARE split_cur CURSOR FOR SELECT psam_id FROM mstb_project_stage_addtional_material
  WHERE psa_id = NEW.psa_id AND psam_status = '3'; 

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; 
  IF(ISNULL(NEW.dsm_updateuser)) THEN
    OPEN split_cur; 
    split_loop : LOOP
      FETCH split_cur INTO psam_id_int; 
      IF done THEN
        LEAVE split_loop; 
      END IF; 

      INSERT INTO mstb_design_split_material (dsm_id,psam_id,mdsm_status) VALUES (NEW.dsm_id,psam_id_int,'1'); 
    END LOOP; 
    CLOSE split_cur; 
  END IF; 
END;
