CREATE TRIGGER TR_before_insert_mstb_purchase_order_main
BEFORE INSERT ON mstb_purchase_order_main
FOR EACH ROW
  BEGIN
  DECLARE max_count INT; 

  SET max_count := ( SELECT COUNT(*) FROM mstb_purchase_order_main b WHERE b.o_provideType_id = new.o_provideType_id AND b.o_stageId = new.o_stageId
                                                                           AND date_format(b.o_createdate ,'%Y-%m-%d') = date_format(new.o_createdate,'%Y-%m-%d')); 

  SET new.o_order_number = CONCAT( new.o_order_number, LPAD(max_count + 1, 2, 0) ); 

END;
