CREATE TRIGGER TR_before_insert_mstb_store_material_outstore
BEFORE INSERT ON mstb_store_material_outstore
FOR EACH ROW
  BEGIN
  DECLARE max_count INT; 

  SET max_count := (SELECT COUNT(*) FROM mstb_store_material_outstore b WHERE b.pv_id = new.pv_id AND b.pro_id = new.pro_id); 
  SET NEW.msmo_no = CONCAT(NEW.msmo_no,LPAD(max_count + 1, 4, 0)); 

END;
