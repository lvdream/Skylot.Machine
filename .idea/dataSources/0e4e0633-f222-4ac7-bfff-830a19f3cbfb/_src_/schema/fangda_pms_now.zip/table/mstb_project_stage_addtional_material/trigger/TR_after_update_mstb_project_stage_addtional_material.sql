CREATE TRIGGER TR_after_update_mstb_project_stage_addtional_material
AFTER UPDATE ON mstb_project_stage_addtional_material
FOR EACH ROW
  BEGIN
  DECLARE dsm_id_int int; 
  DECLARE done INT DEFAULT FALSE; 
  DECLARE status_str VARCHAR(10); 
  DECLARE count_mater_int INT; 
  DECLARE psam_cur cursor for SELECT dsm_id from mstb_design_split_main WHERE psa_id = NEW.psa_id ; 

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; 
  IF(OLD.psam_status = '2' AND NEW.psam_status = '3') THEN
    OPEN psam_cur; 
    psam_loop : LOOP
      FETCH psam_cur INTO dsm_id_int; 
      IF done THEN
        LEAVE psam_loop; 
      END IF; 

      INSERT INTO mstb_design_split_material (dsm_id,psam_id,mdsm_status) VALUES (dsm_id_int,NEW.psam_id,'1'); 
      UPDATE mstb_design_split_main SET dsm_status = '1' WHERE dsm_id = dsm_id_int; 

    END LOOP; 
    CLOSE psam_cur; 
  END IF; 
END;
