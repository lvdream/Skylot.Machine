CREATE TRIGGER TR_after_save_tstb_ftp_car_carinformation
  AFTER INSERT
  ON tstb_ftp_car_information
  FOR EACH ROW
  BEGIN

    CALL sp_tstb_ftp_car_information(

    );
  END;

