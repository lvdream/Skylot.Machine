CREATE PROCEDURE sp_tstb_ftp_car_information()
  BEGIN
    -- 验证当前停车表是否拥有的记录数大于2条
    DECLARE tmp_count INT;

    SET tmp_count = (SELECT count(*)
                     FROM tstb_ftp_car_information);
    IF (tmp_count > 2)
    THEN
      SIGNAL SQLSTATE 'HY000'
      SET MESSAGE_TEXT = 'allow_parking_count_over';
    END IF;
  END;

